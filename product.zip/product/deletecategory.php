<?php
include 'connection.php';

if($_SESSION['id']=="")
{
	header('Location:index.php');
}

//query strings
if(isset($_REQUEST['limit']))
{$limit1="&limit=".$_REQUEST['limit'];}
else{$limit1=="";}
if(isset($_REQUEST['start']))
{$start1="&start=".$_REQUEST['start'];}
else{$start1=="";}
if(isset($_REQUEST['des']))
{$destxt=$_REQUEST['des'];
$dlink="&des=$destxt";
}else{$destxt=$dlink=""; }
if(isset($_REQUEST['cdr']))
{$cdr=$_REQUEST['cdr'];
$clink="&cdr=$cdr";
}else{$cdr=$clink=""; }

$cid=$_REQUEST['cateid'];


$delete="delete from categories where category_id=$cid";
mysqli_query($con,$delete);
echo "<script >
   		 window.location.href ='categorylist.php?dmsg=Record Delete Successfully$limit1$start1$dlink$clink';
	  </script>";
//header('Location:categorylist.php?dmsg=Record Delete Successfully');

?>