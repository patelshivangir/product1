<footer>
		<p class="text-center">Copyrights &copy; by capacity web solitions</p>
	</footer>