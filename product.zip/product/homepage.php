<?php
include 'connection.php';

if($_SESSION['id']=="")
{
	header('Location:index.php');
}
?>
<html>
	<head>
		<title>Home Page</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="styles.css"> 
	</head>	
<body>
  <?php include 'header.php';?>
	
	<h2 class="text-center"><u>PRODUCTS</u></h2>
   <div class="container">
	<table class="table table-striped">
		<tr>
			<th>Product id</th>
			<th>Product Image</th>
			<th>Product Name</th>
			<th>product information</th>
			<th>Product price</th>
			<th>Quentity</th>
			<th>Status</th>
			<th>update</th>
			<th>delete</th>
		</tr>
		<tr>
			<td>1</td>
			<td>path of image</td>
			<td>Tv</td>
			<td>42 inch LCD tv with gard</td>
			<td>42000</td>
			<td>10</td>
			<td>active</td>
			<td><a href="">Update</a></td>
			<td><a href="">delete</a></td>
		</tr>
	</table>
	</div>
  <?php include 'footer.php';?>
</body>
</html>