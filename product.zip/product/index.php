<?php
include 'connection.php';
?>
<?php
if(isset($_POST['btn']))
{
	$unm=$pass="";
	$unmErr=$passErr="";
	
	
		$unm=$_POST['unm'];
		$pass=$_POST['pass'];
	
	
	$select="select * from login where username='$unm' and password='$pass'";
	$result=mysqli_query($con,$select)or die(mysqli_error($con));
	$row=mysqli_fetch_array($result);
	$count=mysqli_num_rows($result);
	
	if($count==1)
	{
		$_SESSION['id']=$row[0];
		header('Location:homepage.php');
	}
	
	$select1="select * from login";
	$result1=mysqli_query($con,$select1);
	$row1=mysqli_fetch_array($result1);
	if($row1[1]!==$unm)
	{
		$error_nm="user name is invalid";
	}
	else
	{
		$error_nm="";
	}
	if($row1[2]!==$pass)
	{
		$error_pass="password is invalid";
	}
	else
	{
		$error_pass="";
	}
	
	
	
}
?>
<html>
	<head>
		<title>login</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		
		<link rel="stylesheet" href="styles.css"> 
		<!--velidation-->
		<script>
			function validation()
			{
				var user=document.getElementById('user').value;
				var pass=document.getElementById('pwd').value;
				if(user=="")
				{
					document.getElementById('user_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('user_error_message').innerHTML="";
					//return false;
				}
				if(pass=="")
				{
					document.getElementById('password_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
			 		document.getElementById('password_error_message').innerHTML="";
					//return false;
				}
			}
		</script>
		<!--reset-->
		<script>
			$(function(){
				$('#btn1').click(function(){
					$('.form-control').val("");
				});
			});
		</script>
		
	</head>	
<body>
	
	<div class="container" id="log">
		<h4 class="text-center"><u>LOGIN</u></h4>
		<form method="post" id="login_form" onsubmit="return validation()">
			<div class="form-group">
		  		<label for="usr">UserName:</label>
		  		<input type="text" class="form-control" id="user" name="unm">
				<span class="error_form" id="user_error_message"><?php if(isset($_POST['btn'])){echo "$error_nm";}?></span>
			</div>
			<div class="form-group">
		  		<label for="pwd">Password:</label>
		  		<input type="password" class="form-control" id="pwd" name="pass">
				<span class="error_form" id="password_error_message"><?php if(isset($_POST['btn'])){ echo "$error_pass";}?></span>
    		</div>
			<div style="padding-left:0px" class="form-group">
				 <input type="submit" name="btn" class="btn btn-primary">
			</div>
		</form>
		<div style="padding-left:80px;margin-top:-48px;">
			<input type="submit" id="btn1" value="reset" class="btn btn-primary">
		</div>
	</div>
</body>
</html>
