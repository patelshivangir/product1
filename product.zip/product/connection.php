<?php
$con=mysqli_connect("localhost","root","","kruepn") or die(mysqli_connect_error());
//echo "connection establish";
session_start();
?>