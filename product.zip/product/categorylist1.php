<?php
include 'connection.php';
if($_SESSION['id']=="")
{
	header('Location:index.php');
}
//multi delete
if(isset($_POST['btn']))
{
	$del=$_POST['ch'];
	$check=implode(",",$del);
	$delete="delete from categories where category_id in ($check)";
	mysqli_query($con,$delete);
	header('Refresh:0');	
}
//query staring
if(isset($_REQUEST['limit']))
{$limit1="&limit=".$_REQUEST['limit'];}
else{$limit1="";}
if(isset($_REQUEST['start']))
{$start1="&start=".$_REQUEST['start'];}
else{$start1="";}

//pegination
$page_name="categorylist.php";
@$limit=$_GET['limit'];

if (isset($_GET["start"])) {
	$page  = $_GET["start"]; 
	} 
	else{ 
	$page=1;
	};  
$start = ($page-1) * $limit; 
if(!$limit > 0 ){ 
$limit = 2; 
}  
 

?>
<html>
	<head>
		<title>category list</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="styles.css"> 
	</head>	
<body>
  <?php include 'header.php'; ?>
	<h2 class="text-center"><u>CATEGORIES</u></h2>
	<?php
  				if(isset($_REQUEST['msg']))
						{
							$msg=$_REQUEST['msg'];
							echo"<div class='alert alert-success'>";
							echo "<span class='glyphicon glyphicon-ok'></span>".$msg;
							echo"</div>";
						}
					if(isset($_REQUEST['dmsg']))
						{
							$msg=$_REQUEST['dmsg'];
							echo"<div class='alert alert-success'>";
							echo "<span class='glyphicon glyphicon-ok'></span>".$msg;
							echo"</div>";
						}
					if(isset($_REQUEST['imsg']))
						{
							$msg=$_REQUEST['imsg'];
							echo"<div class='alert alert-success'>";
							echo "<span class='glyphicon glyphicon-ok'></span>".$msg;
							echo"</div>";
					}	
	
		if(isset($_REQUEST['des']))
		{
			$destxt=$_REQUEST['des'];
			$dquery="(description LIKE '%$destxt%' or category_name LIKE '%$destxt%')";
			$dlink="&des=$destxt";
		}else{$destxt=$dquery=$dlink=""; }
		if(isset($_REQUEST['cdr']))
		{
			$cdr=$_REQUEST['cdr'];
			$cquery="parent_id LIKE '%$cdr%'";
			$clink="&cdr=$cdr";
		}else{$cdr=$cquery=$clink=""; }
	
		if(isset($_POST['btnserch']))
		{
			$cname=$_POST['dr'];
			$sertxt=$_POST['search'];
			if($sertxt=="")
			{$description="";}
			else
			{$description="&des=$sertxt";
			 $dquery="description='$destxt'";
			}
			if($cname=="")
				{$catenm="";}
			else
				{$catenm="&cdr=$cname";}
			
			header('Location:categorylist.php?limit='.$limit.$description.$catenm);
		}
	
		?>
	<form method='POST' >
	<div class='row'>
		<?php
			$drop="select * from categories ";
			$dropresult=mysqli_query($con,$drop);
			$cid=array();
			$pid=array();
			while($droprow=mysqli_fetch_array($dropresult))
			{
				$cid[]=$droprow[0];
				$pid[]=$droprow[3];
			}
		$comm=array_intersect($cid,$pid);
		?>
		<div class="col-md-5"></div>
		<div class="col-md-1"><lable>Search:</lable></div>
		<div class="form-group col-md-2" >
		 <select class="form-control" id="drop" name='dr'>
			  <option value="">--select--</option>
			  <?php 
			foreach($comm as $value)
			{
				$selectarr="select * from categories where category_id=$value";
				$resultarr=mysqli_query($con,$selectarr);
				$rowarr=mysqli_fetch_array($resultarr);
			  	echo "<option "; if(isset($_REQUEST['cdr'])){if($cdr==$rowarr[0]){echo"selected";}} echo" value='$rowarr[0]'>$rowarr[1]</option>";
			}
			 
			  ?>
			 
		  </select>
		</div>
		<div class="form-group col-md-2">
  			<label for="search"></label>
  			<input type="text" class="form-control" name='search' id='search_text' value='<?php if(isset($_REQUEST['des'])){echo $destxt;}?>'>
			
		</div>
		<div class='col-md-2'>
				<input type='submit' value='submit' name='btnserch' class='btn btn-primary'>
			</div>
	</div>
		<div class='container'>
  
		<?php
			
		
			if(isset($_REQUEST['des']) || isset($_REQUEST['cdr']))
			{
				if($destxt!="" && $cdr=="" )
				{$select1="SELECT count(category_id) AS id FROM categories where $dquery";}
				else if($cdr!="" && $destxt=="")
				{$select1="SELECT count(category_id) AS id FROM categories where $cquery"; }
				else
				{$select1="SELECT count(category_id) AS id FROM categories where $cquery and $dquery";}
				$result1 = mysqli_query($con,$select1);
				$count = mysqli_fetch_array($result1);
				$nume = $count[0];
				$total_pages= ceil( $nume / $limit );
			if($nume!=0){	
				echo"<table class='table table-striped' id='datalist'>
				 <tr>
					<th><input type='submit' value='Multiple Delete' id='btn' name='btn' onclick='return checkDelete()' class='btn btn-danger'><br><input style='margin-left:20px'; type='checkbox' id='all'></th>
					<th>Image</th>
					<th>Category Id</th>
					<th>Category Name</th>
					<th>Description</th>
					<th>Parent Category Id</th>
					<th></th>
					<th></th>
				</tr>";
					if($destxt!="" && $cdr==""){
					$select="select * from categories where $dquery LIMIT $start, $limit";}
				    else if($cdr!="" && $destxt==""){
					$select="select * from categories where $cquery LIMIT $start, $limit";}
					else{
					$select="select * from categories where $cquery and $dquery LIMIT $start, $limit";}
					
					$result=mysqli_query($con,$select)or die(mysqli_error($con));
				while($row=mysqli_fetch_array($result))
				{
					
					$selectc="select category_name from categories where category_id=$row[3]";
					$resultc=mysqli_query($con,$selectc)or die(mysqli_error($con));
					$rowc=mysqli_fetch_array($resultc);
					echo"<tr>
					  <td><input type='checkbox' name='ch[]' id='chg' value='$row[0]'></td>
					  <td><img src='$row[4]' width=100px; height='100px;'></td>
					  <td>$row[0]</td>		
					  <td>$row[1]</td>
					  <td>$row[2]</td>";
					  if($row[3]==0)
					  {
					  echo"<td>--</td>";
					  }
					  else
					  {
					  echo"<td>$rowc[0]</td>";
					  }
					  echo"<td><a href='categoryform.php?cateid=$row[0]$limit1$start1$dlink$clink'>Update</a></td>
					  <td><a id='link' onclick='return checkDelete()' href='deletecategory.php?cateid=$row[0]$limit1$start1$dlink$clink'>delete</a></td>
					</tr>
					";
				}
				echo "</table>";
			  }
				else{echo "<h1 class='text-center text-danger'>No Record Found</h1>";}
			}
			else
			{
				$result1 = mysqli_query($con,"SELECT count(category_id) AS id FROM categories");
				$count = mysqli_fetch_array($result1);
				$nume = $count[0];
				$total_pages= ceil( $nume / $limit );
				
				echo"<table class='table table-striped' id='datalist'>
				 <tr>
					<th><input type='submit' value='Multiple Delete' id='btn' name='btn' onclick='return checkDelete()' class='btn btn-danger'><br><input style='margin-left:20px'; type='checkbox' id='all'></th>
					 <th>Image</th>
					<th>Category Id</th>
					<th>Category Name</th>
					<th>Description</th>
					<th>Parent Category Id</th>
					<th></th>
					<th></th>
				</tr>";
				
					$select="select * from categories LIMIT $start, $limit ";
				
					$result=mysqli_query($con,$select)or die(mysqli_error($con));
				while($row=mysqli_fetch_array($result))
				{
					
					$selectc="select category_name from categories where category_id=$row[3]";
					$resultc=mysqli_query($con,$selectc)or die(mysqli_error($con));
					$rowc=mysqli_fetch_array($resultc);
					echo"<tr>
					  <td><input type='checkbox' name='ch[]' id='chg' value='$row[0]'></td>
					  <td><img src='$row[4]' width=100px; height='100px;'></td>
					  <td>$row[0]</td>		
					  <td>$row[1]</td>
					  <td>$row[2]</td>";
					  if($row[3]==0)
					  {
					  echo"<td>--</td>";
					  }
					  else
					  {
					  echo"<td>$rowc[0]</td>";
					  }
					  echo"<td><a href='categoryform.php?cateid=$row[0]$limit1$start1$dlink$clink'>Update</a></td>
					  <td><a id='link' onclick='return checkDelete()' href='deletecategory.php?cateid=$row[0]$limit1$start1$dlink$clink'>delete</a></td>
					</tr>";
					
				 }
				echo "</table>";
			}
?>
			
	</div>
		
		<!--script>
			$(document).ready(function(){
				$('#search_text').keyup(function(){
					var search=$('#search_text').val();
						$.ajax({
							url:'searchcategoryajax.php',
							method:'POST',
							data:'query='+search,
							success:function(data)
							{
								$('#pagination_data').html(data);
							}
						});
				});
				
				$('#drop').change(function(){
					var nm=$('#drop').val();
						$.ajax({
							url:'searchcategoryajax.php',
							method:'POST',
							data:'drop='+nm,
							success:function(data)
							{
								$('#pagination_data').html(data);
							}
						});
				});
			});
		</script-->
		
		<!--pagination-->
		<?php
	if(isset($_REQUEST['des']) || isset($_REQUEST['cdr']))
	{

		echo "<ul style='margin-left:500px' class='pagination'>";

		if($page>1) { 
		echo "<li ><a class='page-link' href='categorylist.php?start=".($page-1)."&limit=$limit$dlink$clink'>Privious</a></li>"; 
		} 

		for($i=1;$i <= $total_pages;$i++)
		{
			if($page==$i){
			echo "<li class='active'> <a href='$page_name?start=$i&limit=$limit$dlink$clink'>$i</a></li> ";
			}
			else { echo "<li> <a href='$page_name?start=$i&limit=$limit$dlink$clink'>$i</a></li> ";}        

		}

		if($page<($i-1)) { 
		echo "<li><a class='page-link' href='categorylist.php?start=".($page+1)."&limit=$limit$dlink$clink'>Next</a></li>";} 
		echo "</ul>";
	}
	else
	{
			echo "<ul style='margin-left:500px' class='pagination'>";

		if($page>1) { 
		echo "<li ><a class='page-link' href='categorylist.php?start=".($page-1)."&limit=$limit'>Privious</a></li>"; 
		} 



		for($i=1;$i <= $total_pages;$i++){
		if($page==$i){
		echo "<li class='active'> <a href='$page_name?start=$i&limit=$limit'>$i</a></li> ";
		}
		else { echo "<li> <a href='$page_name?start=$i&limit=$limit'>$i</a></li> ";}        

		}

		if($page<($i-1)) { 
		echo "<li><a class='page-link' href='categorylist.php?start=".($page+1)."&limit=$limit'>Next</a></li>";} 


		echo "</ul>";
	}
		?>
		
		</form>
	<form action='categorylist.php'>
	<div class="divnum_rows">
                <span>Number of rows:</span>&nbsp;
                <select id="num_rows" name="limit">
                    <?php
                    $numrows_arr = array("2","3","4","5","6","7","8","9","10");
                    foreach($numrows_arr as $nrow){
                        if(isset($_GET['limit']) && $_GET['limit'] == $nrow){
                            echo '<option value="'.$nrow.'" selected="selected">'.$nrow.'</option>';
                        }else{
                            echo '<option value="'.$nrow.'">'.$nrow.'</option>';
                        }
                    }
                    ?>
                </select>
			<input type=submit value=submit class='btn btn-primary'>
                </div>
	</form>
	<?php
	if($nume==0)
	{
	}else{
	echo "<div style='margin-left:1000px;margin-top:-50px;'>";
	echo "<h4>Total Record:$nume</h4>";
	echo "<h5>Page $page of $total_pages</h5>";
	echo "</div>";}
	?>
	<!--confrim befor delete-->
		<script language="JavaScript" type="text/javascript">
		function checkDelete(){
   			 return confirm('Are you sure you want to delete?');
		}
		</script>
	<!--multipal select checkbox-->
	<script>
			$(function(){
				$('#all').click(function() {
					if ($(this).is(':checked')) {
						$('div input').attr('checked', true);
					} else {
						$('div input').attr('checked', false);
					}
				});
			});
		</script>
		
		
  <?php include 'footer.php';?>
</body>
</html>
