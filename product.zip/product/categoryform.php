<?php
include 'connection.php';

if($_SESSION['id']=="")
{
	header('Location:index.php');
}
//query strings
$limit1=$start1="";
if(isset($_REQUEST['limit']))
{$limit1="&limit=".$_REQUEST['limit'];}
else{$limit1=="";}
if(isset($_REQUEST['start']))
{$start1="&start=".$_REQUEST['start'];}
else{$start1=="";}
if(isset($_REQUEST['des']))
{$destxt=$_REQUEST['des'];
$dlink="&des=$destxt";
}else{$destxt=$dlink=""; }
if(isset($_REQUEST['cdr']))
{$cdr=$_REQUEST['cdr'];
$clink="&cdr=$cdr";
}else{$cdr=$clink=""; }

$cid="";
if(isset($_REQUEST['cateid'])){
$cid=$_REQUEST['cateid'];}
if($cid=="")
{
	if(isset($_POST['btn']))
	{
		 $cateErr =$descErr="";
		 $catename= $description="";
		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
            if (empty($_POST['cnm'])) {
               $cateErr = "category is required";
            }else {
               $catename = $_POST['cnm'];
            }
			if (empty($_POST['desc'])) {
               $descErr = "description is required";
            }else {
              $description = $_POST['desc'];
            }
			
		 function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }
			
		$fil=$_FILES['img']['name'];
		$temp=$_FILES['img']['tmp_name'];
		$e=explode(".",$fil);
		$ext=strtolower(end($e));
		$path="images/$fil";
		if($ext=="jpg" || $ext=="jpeg" || $ext=="png")
		{
			move_uploaded_file($temp, $path);
		}
		else
		{
			echo "error";
		}
	}
			
		
		$parent="";
		$parent=$_POST['parentid'];

		if($parent==0)
		{
		$insert="insert into categories values(0,'$catename','$description',0,'$path')";
		}
		else
		{
			$insert="insert into categories values(0,'$catename','$description','$parent','$path')";
		}
		mysqli_query($con,$insert);
		$success="Data Inserted Successfully";
		header('Location:categorylist.php?imsg='.$success);
	}
}
else
{
	$selectc="select * from categories where category_id='$cid'";
	$resultc=mysqli_query($con,$selectc)or die(mysqli_error($con));
	$rowc=mysqli_fetch_array($resultc);
}

?>
<html>
	<head>
		<title>add category</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="styles.css"> 
		
		<!--velidation-->
		<script>
			function validation()
			{
				var cnm=document.getElementById('cnm').value;
				var desc=document.getElementById('desc').value;
				var img=document.getElementById('img').value;
				
				if(cnm=="")
				{
					document.getElementById('cnm_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('cnm_error_message').innerHTML="";
					//return false;
				}
				if(desc=="")
				{
					document.getElementById('desc_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
			 		document.getElementById('desc_error_message').innerHTML="";
					//return false;
				}
				/*if(img=="")
				{
					document.getElementById('img_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
			 		document.getElementById('img_error_message').innerHTML="";
					//return false;
				}*/
				
			}
		</script>
		
		<!--reset-->
		<script>
			$(function(){
				$('#btn1').click(function(){
					$('.form-control').val("");
				});
			});
		</script>
		
	</head>	
<body>
  <?php include 'header.php';?>
	<h2 class="text-center"><u>Category Form</u></h2>
	<div class="container" style="height:500px;width:500px;background-color:lightgray;border-radius: 25px; ">
	  <form method="post" enctype="multipart/form-data" onsubmit="return validation()">
		  <div class="form-group" style="margin-top:30px;">
		  <label for="img">Image:</label>
		  <input type="file" class="form-control" name="img" id="img" value="<?php if($cid!=""){echo $rowc[4];}?>">
			<span class="error_form" id="img_error_message"></span>
		</div>
		<!--category name-->
		<div class="form-group">
		  <label for="cnm">Category Name:</label>
		  <input type="text" class="form-control" name="cnm" id="cnm" value="<?php if($cid!=""){echo "$rowc[1]";}?>">
			<span class="error_form" id="cnm_error_message"><?php if(isset($_POST['btn'])){if($cid==""){echo "$cateErr";}}?></span>
		</div>
		 
		  <!--description-->
		  <div class="form-group">
			  <label for="comment">Description:</label>
			  <textarea class="form-control" rows="5" id="desc" name="desc"><?php if($cid!=""){echo "$rowc[2]";}?></textarea>
			  <span class="error_form" id="desc_error_message"><?php if(isset($_POST['btn'])){if($cid==""){echo "$descErr";}}?></span>
		  </div>
		  <!--parent id-->
		  <div class="form-group">
			  <label for="parent">Parent Id:</label>
			  <select class="form-control" id="parent" name="parentid">
				  <option value=0>--select option--</option>
				   
				  <?php
				  	$select="select * from categories";
				  	$result=mysqli_query($con,$select)or die(mysqli_error($con));
				  
				  	while($row=mysqli_fetch_array($result))
					{
						echo " <option "; if($cid!=""){if($row[0]==$rowc[3]){echo" selected ";}} echo" value='$row[0]'>$row[1]</option>";
					}
				  ?>
			 
			  </select>
			  <span class="error_form" id="parent_error_message"></span>
			</div>
		  <!--button-->
		  <div class="form-group">
				<input type="submit" name="btn" class="btn btn-primary">
		  </div>
	</form> 
		
		<?php
if($cid!="")
{
	if(isset($_POST['btn']))
	{
		$catename=$_POST['cnm'];	
		$description=$_POST['desc'];
		$parent="";
		$parent=$_POST['parentid'];
		$fil=$_FILES['img']['name'];
		$temp=$_FILES['img']['tmp_name'];
		$e=explode(".",$fil);
		$ext=strtolower(end($e));
		$path="images/$fil";
		if($ext=="jpg" || $ext=="jpeg" || $ext=="png")
		{
			move_uploaded_file($temp, $path);
		}
		else
		{
			echo "error";
		}

		if($parent==0)
		{
			if($fil=="")
			{
			$update="update categories set category_name='$catename', description='$description', parent_id=0 where category_id='$cid'";
			}
			else
			{
				$update="update categories set category_name='$catename', description='$description', parent_id=0, category_image='$path' where category_id='$cid'";
			}
		}
		else
		{
			if($fil=="")
			{
				$update="update categories set category_name='$catename', description='$description', parent_id='$parent' where category_id='$cid'";
			}
			else
			{
				$update="update categories set category_name='$catename', description='$description', parent_id=$parent, category_image='$path' where category_id='$cid'";
			}
		}
		mysqli_query($con,$update);
		echo "<script >
   				 window.location.href ='categorylist.php?msg= Data Updated Successfully$limit1$start1$dlink$clink';
			</script>";
		//header('Location:categorylist.php?start='.$start.'&limit='.$limit.'&msg= Data Updated Successfully&des='.$des.'&cdr='.$cdr);
	}
}
?>
		
		<?php if($cid==""){
		echo "<div style='padding-left:80px;margin-top:-48px;'>
			   <input type='submit' id='btn1' value='reset' class='btn btn-primary'>
		      </div>";
		}
			  ?>
		
   </div>
  <?php include 'footer.php';?>
</body>
</html>

