<?php
include 'connection.php';

$record_per_page ="";
if(!$record_per_page>0 && !isset($_POST['limit']))
{
	$record_per_page =2;
}
else{
$record_per_page = $_POST['limit'];
}
 $page = '';  
 $output = '';  
 if(isset($_POST["page"]))  
 {  
      $page = $_POST["page"];  
 }  
 else  
 {  
      $page = 1;  
 }  
 $start_from = ($page - 1)*$record_per_page; 

if(isset($_POST['drop']) || isset($_POST['query']))
{
	$des=$_POST['query'];
	$drop=$_POST['drop'];
	 
	echo"<table class='table table-striped' id='datalist'>
				 <tr>
					<th><input type='submit' value='Multiple Delete' id='btn' name='btn' onclick='return checkDelete()' class='btn btn-danger'><br><input style='margin-left:20px'; type='checkbox' id='all'></th>
					<th>Image</th>
					<th>Category Id</th>
					<th>Category Name</th>
					<th>Description</th>
					<th>Parent Category Id</th>
					<th></th>
					<th></th>
				</tr>";
				
				if($des=="" && $drop!=""){
				$select1="SELECT count(category_id) AS id FROM categories where parent_id=$drop LIMIT $start_from, $record_per_page";}
				else if($des!="" && $drop==""){
				$select1="SELECT count(category_id) AS id FROM categories where category_name LIKE '%$des%' or description LIKE '%$des%' LIMIT $start_from, $record_per_page";}
				else{
				$select1="SELECT count(category_id) AS id FROM categories where category_id=$drop and (category_name LIKE '%$des%' or description LIKE '%$des%')LIMIT $start_from, $record_per_page";}
	
				$result1 = mysqli_query($con,$select1);
				$count = mysqli_fetch_array($result1);
				$nume = $count[0];
				$total_pages = ceil( $nume / $record_per_page );
		
				if($des=="" && $drop!=""){
				$select="select * from categories where parent_id=$drop";}
				else if($des!="" && $drop==""){
				$select="select * from categories where category_name LIKE '%$des%' or description LIKE '%$des%'";}
				else{
				$select="select * from categories where category_id=$drop and (category_name LIKE '%$des%' or description LIKE '%$des%')";}
					$result=mysqli_query($con,$select)or die(mysqli_error($con));
				while($row=mysqli_fetch_array($result))
				{
					
					$selectc="select category_name from categories where category_id=$row[3]";
					$resultc=mysqli_query($con,$selectc)or die(mysqli_error($con));
					$rowc=mysqli_fetch_array($resultc);
					echo"<tr>
					  <td><input type='checkbox' name='ch[]' id='chg' value='$row[0]'></td>
					  <td><img src='$row[4]' width=100px; height='100px;'></td>
					  <td>$row[0]</td>		
					  <td>$row[1]</td>
					  <td>$row[2]</td>";
					  if($row[3]==0)
					  {
					  echo"<td>--</td>";
					  }
					  else
					  {
					  echo"<td>$rowc[0]</td>";
					  }
					  echo"<td><a href='categoryform.php?cateid=$row[0]'>Update</a></td>
					  <td><a id='link' onclick='return checkDelete()' href='deletecategory.php?cateid=$row[0]'>delete</a></td>
					  </tr>";
					
					 }
					echo "</table>";
					echo "<div style='margin-left:500px'>";
				if($page>1) {
					echo "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".($page-1)."'>PREV</span>";  }
				for($i=1; $i<=$total_pages; $i++)  
				 {  
					 if($page==$i){
					  echo "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc; background-color:lightblue' id='".$i."'>".$i."</span>"; 
					 }
					 else
					 {
						echo "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".$i."'>".$i."</span>";
					 }
				 }  
				if($page<($i-1)) { 
				echo "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".($page+1)."'>NEXT</span>";}
					  echo '</div><br /><br />';  
	
	
	if($nume==0)
	{
		echo "<div style='margin-left:1000px;margin-top:-50px;'>";
		echo "<h4>Total Record:$nume</h4>";
		echo "<h5>Page $page of $total_pages</h5>";
		echo "</div>";
	}
}
?>