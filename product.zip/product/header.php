<header>
	<nav class="navbar navbar-inverse">
	  <div class="container-fluid">
		<div class="navbar-header">
		  <a class="navbar-brand" href="homepage.php">CWS</a>
		</div>
		<ul class="nav navbar-nav">
		  <li><a href="homepage.php">Home</a></li>
		  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Categories <span class="caret"></span></a>
			<ul class="dropdown-menu">
			  <li><a href="categoryform.php">Add Categories</a></li>
			  <li><a href="categorylist.php">Categories List</a></li>
			</ul>
		  </li>
		  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Products <span class="caret"></span></a>
			<ul class="dropdown-menu">
			  <li><a href="productform.php">Add Products</a></li>
			  <li><a href="productlist.php">Products List</a></li>
			</ul>
		  </li>
		  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Order <span class="caret"></span></a>
			<ul class="dropdown-menu">
			  <li><a href="orderform.php">Add Order</a></li>
			  <li><a href="orderlist.php">Order List</a></li>
			</ul>
		  </li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	  
	  </div>
	</nav>
  </header>