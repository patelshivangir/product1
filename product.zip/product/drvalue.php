<?php
include 'connection.php';


if(isset($_POST['id']))
{
	$record_per_page =$_POST['id'];  
	
}

else
{
	$record_per_page =2;
}

 $page = '';  
 $output = '';  
 if(isset($_POST["page"]))  
 {  
      $page = $_POST["page"];  
	 echo $page;
 }  
 else  
 {  
      $page = 1;  
 }  
 $start_from = ($page - 1)*$record_per_page;  
			$select="select * from categories LIMIT $start_from, $record_per_page";
			$result=mysqli_query($con,$select)or die(mysqli_error($con));
		   
$output .="<table class='table table-striped'>
		 <tr>
			<th><input type='submit' value='Delete' id='btn' name='btn' onclick='return checkDelete()' class='btn btn-danger'><br><input style='margin-left:20px'; type='checkbox' id='all'></th>
			<th>Category Id</th>
			<th>Category Name</th>
			<th>Description</th>
			<th>Parent Category Id</th>
			<th></th>
			<th></th>
		</tr>";
 while($row=mysqli_fetch_array($result))
 {
	 			$selectc="select category_name from categories where category_id='$row[3]'";
				$resultc=mysqli_query($con,$selectc)or die(mysqli_error($con));
				$rowc=mysqli_fetch_array($resultc);
	 	
	 $output .="<tr>
				  <td><input type='checkbox' name='ch[]' id='chg' value='$row[0]'></td>
				  <td>$row[0]</td>		
				  <td>$row[1]</td>
				  <td>$row[2]</td>";
	 			if($row[3]==0)
				  {
					   $output .="<td>--</td>";
				  }
	  			else
				  {
					  $output .="<td>$rowc[0]</td>";
				  }
	 	$output .="<td><a href='categoryform.php?cateid=$row[0]'>Update</a></td>
				  <td><a id='link' onclick='return checkDelete()' href='deletecategory.php?cateid=$row[0]'>delete</a></td>
				</tr>";
 }
$output .= '</table><div align="center">';
$page_query = "SELECT * FROM categories";  
 $page_result = mysqli_query($con, $page_query);  
 $total_records = mysqli_num_rows($page_result);  
 $total_pages = ceil($total_records/$record_per_page);  
if($page>1)
{
$output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".($page-1)."'><</span>";
}
 for($i=1; $i<=$total_pages; $i++)  
 {  
	 if($page==$i)
	 {
      $output .= "<span class='pagination_link' style='cursor:pointer; background-color:lightblue; padding:6px; border:1px solid #ccc;' id='".$i."'>".$i."</span>";  
	 }
	 else
	 {
      $output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".$i."'>".$i."</span>";  
	 }
 }  
if($page<($i-1))
{
$output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".($page+1)."'>></span>";
}
 $output .= '</div><br /><br />'; 
$output .="	<script>
			$(function(){
				$('#all').click(function() {
					if ($(this).is(':checked')) {
						$('div input').attr('checked', true);
					} else {
						$('div input').attr('checked', false);
					}
				});
			});
		</script>";
 echo $output;  
?>
		
	