
<?php
include 'connection.php';
if($_SESSION['id']=="")
{
	header('Location:index.php');
}

if(isset($_POST['btn']))
{
	$productsku=$_POST['sku'];
	$productcate=$_POST['category'];
	$product_info=$_POST['info'];
	$productprice=$_POST['price'];
	$quantiti=$_POST['quantity'];
	$status=$_POST['status'];
	$fil=$_FILES['img'];
	print_r($fil);

}

?>
<html>
	<head>
		<title>add category</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="styles.css"> 
		
		<!--velidation-->
		<script>
			function validation()
			{
				var img=document.getElementById('img').value;
				var sku=document.getElementById('sku').value;
				var category=document.getElementById('category').value;
				var info=document.getElementById('info').value;
				var price=document.getElementById('price').value;
				var quantity=document.getElementById('quantity').value;
				var status=document.getElementById('status').value;
				
				if(img=="")
				{
					document.getElementById('fil_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('fil_error_message').innerHTML="";
					//return false;
				}
				if(sku=="")
				{
					document.getElementById('sku_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
			 		document.getElementById('sku_error_message').innerHTML="";
					//return false;
				}
				if(category==0)
				{
					document.getElementById('cate_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('cate_error_message').innerHTML="";
					//return false;
				}
				if(info=="")
				{
					document.getElementById('info_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('info_error_message').innerHTML="";
					//return false;
				}
				if(price=="")
				{
					document.getElementById('price_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('price_error_message').innerHTML="";
					//return false;
				}
				if(quantity=="")
				{
					document.getElementById('quantiti_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('quantiti_error_message').innerHTML="";
					//return false;
				}
				if(status=="")
				{
					document.getElementById('status_error_message').innerHTML="fild is required";
					return false;
				}
				else
				{
					document.getElementById('status_error_message').innerHTML="";
					//return false;
				}
				
			}
		</script>
		
		<!--reset-->
		<script>
			$(function(){
				$('#btn1').click(function(){
					$('.form-control').val("");
				});
			});
		</script>
	</head>	
<body>
  <?php include 'header.php';?>
	<h2 class="text-center"><u>Product Form</u></h2>
	<div class="container" style="height:700px;width:500px;background-color:lightgray;border-radius: 25px; ">
	  <form method="post" enctype="multypart/form-data" onsubmit="return validation()">
		<!--image-->
		<div class="form-group" style="margin-top:30px;">
		  <label for="img">Product Image:</label>
		  <input type="file" class="form-control" name="img" id="img">
		  <span class="error_form" id="fil_error_message"></span>
		</div>
		
		<!--sku-->
		<div class="form-group">
		  <label for="sku">Product SKU:</label>
		  <input type="text" class="form-control" name="sku" id="sku">
			<span class="error_form" id="sku_error_message"></span>
		</div>
		<!--category-->
		<div class="form-group">
		  <label for="category">category:</label>
		   <select class="form-control" id="category" name="category" id="category">
				  <option value=0>--select option--</option>
				   
				  <?php
				  	$select="select * from categories";
				  	$result=mysqli_query($con,$select)or die(mysqli_error($con));
				  
				  	while($row=mysqli_fetch_array($result))
					{
						echo " <option value='$row[0]'>$row[1]</option>";
					}
				  ?>
			 
			  </select>
			<span class="error_form" id="cate_error_message"></span>
		</div>
		<!--info-->
		<div class="form-group">
		  <label for="info">Product Information:</label>
		  <textarea class="form-control" rows="5" name="info" id="info"></textarea>
			<span class="error_form" id="info_error_message"></span>
		</div>
		<!--price-->
		<div class="form-group">
		  <label for="price">Product Price:</label>
		  <input type="number" class="form-control" name="price" id="price">
			<span class="error_form" id="price_error_message"></span>
		</div>
		  
		<!--quntity-->
		<div class="form-group">
		  <label for="quantity">Quantity:</label>
		  <input type="number" class="form-control" name="quantity" id="quantity">
			<span class="error_form" id="quantiti_error_message"></span>
		</div>
		  
		 <!--category-->
		<div class="form-group">
		  <label for="status">Status:</label>
		   <select class="form-control" id="status" name="status" id="status">
				 <option value="0">--select option--</option>
			    <option value="aciive">Active</option>
			    <option value="inactive">Inactive</option>
		   </select>
			<span class="error_form" id="status_error_message"></span>
		  </div>
		  
		   <!--button-->
		  <div class="form-group">
				<input type="submit" name="btn" class="btn btn-primary">
		  </div>
	</form> 
		<div style='padding-left:80px;margin-top:-48px;'>
		  <input type='submit' id='btn1' value='reset' class='btn btn-primary'>
		</div>
   </div>
  <?php include 'footer.php';?>
</body>
</html>