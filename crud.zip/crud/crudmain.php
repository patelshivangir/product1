<?php
//index.php
include 'crud.php';
$object = new Crud();
?>
<html>
 <head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
   body
   {
    margin:0;
    padding:0;
    background-color:#f1f1f1;
   }
   .box
   {
    width:1270px;
    padding:20px;
    background-color:#fff;
    border:1px solid #ccc;
    border-radius:5px;
    margin-top:10px;
   }
    .nav{
	width:100%;
	background:#000033;
	height:80px;
		}
			
			
ul{
	list-style:none;
	padding:0;
	margin:0;
	position:relative;
			}
ul li{
	float:left;
	margin-top:20px;
				}
ul li a{
	width:150px;
	color:white;
	display:block;
	text-decoration:none;
	font-size:20px;
	text-align:center;
	padding:10px;
	border-radius:10px;
	font-family:Century Gothic;
	font-weight:bold;
				}

ul li ul{
	background:#000033;}
ul li ul li{
	float:none;
		}
ul li ul{
	display:none;
	
	}
ul li:hover ul{
	display:block;
	overflow:hide;
  color:white;
				}
/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
  </style>
 </head>
 <body>
   		<div class="nav">
			<ul>
				<li><a href="Dashboard.php">Dashboard</a></li>
				
				<li><a href="add-category.php">Add category</a></li> 
				<li><a href="view-category.php">View category</a></li>
			
					<li><a href="add-product-details.php">Add Product</a></li>
				<li><a href="view-product.php">View Product</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
	</div>	
  <div class="container box">
   <h3 align="center"></h3><br /><br />
   <div class="col-md-8">
    <button type="button" name="add" id="add" class="btn btn-success" data-toggle="collapse" data-target="#user_collapse">filter</button>
   </div>

    
   <div class="col-md-4">
    <input type="text" name="search" id="search" placeholder="Search" class="form-control" />
   </div>
   <br />
   <br />
   <div id="user_collapse" class="collapse">
    <form method="post" id="user_form">
     <label>Enter Product Name</label>
     <input type="text" name="first_name" id="first_name" class="form-control" />
     <br />
     <label>Enter Product Description</label>
     <input type="text" name="last_name" id="last_name" class="form-control" />
     <br />
       <br />
     <label>Enter Product Price</label>
     <input type="text" name="last_name" id="last_name" class="form-control" />
     <br />
       <br />
     <label>Enter Product quantity</label>
     <input type="text" name="last_name" id="last_name" class="form-control" />
     <br />
   
     <label>Select Product Image</label>
     <input type="file" name="user_image" id="user_image" />
     <input type="hidden" name="hidden_user_image" id="hidden_user_image" />
     <span id="uploaded_image"></span>
     <br />
     <div align="center">
      <input type="hidden" name="action" id="action" />
      <input type="hidden" name="product_id" id="product_id" />
      <input type="submit" name="button_action" id="button_action" class="btn btn-default" value="Insert" />
     </div>
      
    </form>
       
   </div>
  
   <br /><br />
   <div id="user_table" class="table-responsive">
    
   </div>
       <label>show </label>
                 <select name="perPageLimit" onchange="this.form.submit()">
                <option value="5" selected> <a href="crudmain.php?id=<?php echo $record; ?>">5</a></option>
                  <option value="10" ><a href="crudmain.php?id=<?php echo $record; ?>">10</a></option>
                      <option value="20" ><a href="crudmain.php?id=<?php echo $record; ?>">20</a></option>
                 </select>
  </div>
       
 </body>
</html>

<script type="text/javascript">
 $(document).ready(function(){

  load_data();

  $('#action').val("Insert");

  $('#add').click(function(){
   $('#user_form')[0].reset();
   $('#uploaded_image').html('');
   $('#button_action').val("Insert");
  });
  function load_data(page)
  {
   var action = "Load";
   $.ajax({
    url:"action.php",
    method:"POST",
    data:{action:action, page:page},
    success:function(data)
    {
     $('#user_table').html(data);
    }
   });
  }

  $(document).on('click', '.pagination_link', function(){
   var page = $(this).attr("id");
   load_data(page);
  });

  $('#user_form').on('submit', function(event){
   event.preventDefault();
   var firstName = $('#first_name').val();
   var lastName = $('#last_name').val();
   var extension = $('#user_image').val().split('.').pop().toLowerCase();
   if(extension != '')
   {
    if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
    {
     alert("Invalid Image File");
     $('#user_image').val('');
     return false;
    }
   }
   if(firstName != '' && lastName != '')
   {
    $.ajax({
     url:"action.php",
     method:"POST",
     data:new FormData(this),
     contentType:false,
     processData:false,
     success:function(data)
     {
      alert(data);
      $('#user_form')[0].reset();
      load_data();      
      $('#action').val("Insert");
      $('#button_action').val("Insert");
      $('#uploaded_image').html('');
     }
    })
   }
   else
   {
    alert("Both Fields are Required");
   }
  });

  $(document).on('click', '.update', function(){
   var user_id = $(this).attr("id");
   var action = "Fetch Single Data";
   $.ajax({
    url:"action.php",
    method:"POST",
    data:{user_id:user_id, action:action},
    dataType:"json",
    success:function(data)
    {
     $('.collapse').collapse("show");
     $('#first_name').val(data.first_name);
     $('#last_name').val(data.last_name);
     $('#uploaded_image').html(data.image);
     $('#hidden_user_image').val(data.user_image);
     $('#button_action').val("Edit");
     $('#action').val("Edit");
     $('#user_id').val(user_id);
    }
   });
  });
  
  $(document).on('click', '.delete', function(){
   var user_id = $(this).attr("id");
   var action = "Delete";
   if(confirm("Are you sure you want to delete this?"))
   {
    $.ajax({
     url:"action.php",
     method:"POST",
     data:{user_id:user_id, action:action},
     success:function(data)
     {
      alert(data);
      load_data();
     }
    });
   }
   else
   {
    return false;
   }
  });
  
  $('#search').keyup(function(){
   var query = $('#search').val();
   var action = "Search";
   if(query != '')
   {
    $.ajax({
     url:"action.php",
     method:"POST",
     data:{query:query, action:action},
     success:function(data)
     {
      $('#user_table').html(data);
     }
    });
   }
   else
   {
    load_data();
   }
  });
  
 });
</script>