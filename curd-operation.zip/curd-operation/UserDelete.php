<?php
	include('config/config.php');
	if($_SERVER['REQUEST_METHOD'] == 'POST') {
		$ajax_data = json_decode(file_get_contents('php://input'), true);
		$id = ($ajax_data!="") ? $db->real_escape_string($ajax_data) : '';
		if($id!="") :
            $query = "DELETE FROM users_information WHERE id=$id";
			$sql = $db->query($query);
            $msg = "Successfully Deleted Your Record";
        else:  
			$msg = "Something went wrong Please Check Reload your File.";
        endif;
		echo $msg;
	}	
?>