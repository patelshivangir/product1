<html ng-app="my_app">
<head>
	<title>AngularJS Add,Edit,Update,Delete using Boostrap modal with DataTable in PHP</title>
	<link href='http://www.mostlikers.com/favicon.ico' rel='icon' type='image/x-icon'/>
	<!--Bootstrap CSS --> 
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/dataTables.bootstrap.min.css" rel="stylesheet">
	<link href="css/custom-style.css" rel="stylesheet">
	<!--/Bootstrap CSS --> 
	
	<!--JQuery DataTables--> 
	<script type="text/javascript" src="//code.jquery.com/jquery-1.12.4.js"></script>
	<script src="js/bootstrap/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/dataTables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/dataTables/dataTables.bootstrap.min.js"></script>
	<!--/JQuery DataTables --> 
	
	<!--Angualrjs --> 
		<script type="text/javascript" src="js/angularjs/angular.min.js"></script>
		<script type="text/javascript" src="js/angularjs/angular-datatables.min.js"></script>
		<script type="text/javascript" src="js/angularjs/users.angular.js"></script>
	<!--/Angualrjs --> 
</head>
<body>
<div ng-controller="users" data-ng-init="usersInformation()" class="container">
	<div class="col-md-12">
		<h3 class="text-center">AngularJS Add,Edit,Update,Delete using Boostrap modal with DataTable in PHP</h3>
		<h4 class="text-center"><a href="http://www.mostlikers.com/2017/09/angularjs-insert-update-delete-php-mysql.html">Tutorials Link</a> - <a href="http://www.mostlikers.com/">mostlikers.com</a></h4>
		<div>
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- Google ads Code -->
			<ins class="adsbygoogle"
				 style="display:block"
				 data-ad-client="ca-pub-9665679251236729"
				 data-ad-slot="9239985429"
				 data-ad-format="auto"></ins>
			<script>
			(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
		</div>
	</div>
	<div class="col-md-12">
		<div class="add_panel">
			<a ng-click="addModal();" class="model_form btn btn-primary">
				<i class="glyphicon glyphicon-plus"></i> Add User</a>
            <div class="clearfix"></div>
		</div>
		<div class="table-responsive">
			<table datatable="ng"  id="examples" 
				class="table table-striped table-bordered" cellspacing="0" 
					width="100%">
				<thead>
					<tr>
						<th>S.No</th>
						<th>Name</th>
						<th>Email</th>
						<th>Position</th>
						<th>Data Of Birth</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<tr ng-repeat="user in users_list">
						<td>{{$index + 1}}</td>
						<td>{{user.name}}</td>
						<td>{{user.email}}</td>
						<td>{{user.position}}</td>
						<td>{{user.dob | date: "yyyy-MM-dd"}}</td>
						<td>
							<a href="javascript:void(0);" ng-click="EditModal(user);"> 
								<i class="glyphicon glyphicon-pencil"></i>
							</a>
							<a href="javascript:void(0);" ng-click="DeleteModal(user)" class="delete"> 
								<i class="glyphicon glyphicon-remove"></i> 
							</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div ng-if="success_msg" class="success_pop alert alert-success">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			 <strong> {{success_msg}} </strong> 
		</div>
	</div>
    
    
<!-- Form modal -->
  <div id="form_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title"><i class="icon-paragraph-justify2"></i>
          {{form_name}}</h4>
        </div>
        <!-- Form inside modal -->
        <form  method="post" ng-submit="UserAddUpdate(users_form);" id="cat_form">
          <div class="modal-body with-padding">
            <div class="form-group">
              <div class="row">
                <div class="col-sm-12">
                  <label>Name :</label>
                   <input type="text" name="name" ng-model="users_form.name" 
						id="name" required="required" class="form-control">
                </div>
              </div>
            </div>            
            <div class="form-group">
              <div class="row">
                <div class="col-sm-12">
                  <label>Email :</label>
                   <input type="email" name="email" ng-model="users_form.email" 
						id="email" required="required"  class="form-control email">
                </div>
              </div>
            </div>
			<div class="form-group">
              <div class="row">
                <div class="col-sm-12">
                  <label>Position :</label>
                   <input type="text" name="position" ng-model="users_form.position" 
						id="position" required="required"  class="form-control">
                </div>
              </div>
            </div>
              <div class="row">
                <div class="col-sm-12">
                  <label>Birthday :</label>
                   <input type="date" placeholder="yyyy-MM-dd" id="dob" 
							max="<?php echo date('Y-m-d'); ?>" ng-model="users_form.dob" 
					class="form-control" required="required"  name="dob">
                </div>
              </div>
            </div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
			  <button type="submit" name="form_data" class="btn btn-primary">Submit</button>
			</div>
        </form>
      </div>
    </div>
  </div>
<!-- /form modal -->     
</div>
</body>
</html>

