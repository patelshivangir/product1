<?php
$user = 'root';
$password = '';
$database = 'mostlikers';
$db = new mysqli('localhost',$user,$password,$database);
if(!$db):
	echo 'Your database connection not exist'; exit;
endif;
?>