<?php
	include('config/config.php');
	$users_information = array();
	if ($result = $db->query("SELECT * FROM users_information")) {

		while($row = $result->fetch_array(MYSQL_ASSOC)) {
				$users_information[] = $row;
		}
		echo json_encode($users_information);
	}
	
?>