<?php include('inc/config.php'); 

if(isset($_SESSION['user_id']) && $_SESSION['user_id'] != ''){
     header('location:dashbord.php');  
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Login</title>
        <?php include('inc/head.php'); ?>
        <script type="text/javascript" language="javascript" src="js/login.js"></script>
        
    </head>
    <body>
       <div class="container">
           <main class="login-form">
          <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header" style="font-size:25px;">Login your account</div>
                       <div class="card-body">
                          <span id="loginError" class="error"></span>
                          <span style="color:green; font-size:17px;"><?php if($_REQUEST['m'] == 1){ echo "Password is sent to your mail id"; } ?></span>
                          <form id="loginForm" name="loginForm">
                         <div class="form-group">
                            <label for="email">Email <span class="error">*</span> :</label>
                          <input type="email" id="username" class="form-control" placeholder="Email" name="username"/>
                         </div>
                         <span id="unameValid"></span>
                       
                      <div class="form-group">
                        
                           <label for="password">Password <span class="error">*</span> :</label>

                          <input type="password" id="password" class="form-control" placeholder="Password" name="password"/>
                        </div>
                        <span id="passwordValid"></span>
                       <div class="form-group" style="text-align:right; margin-top:10px;">            
                        <a href="forgotPwd.php" name="forgotPwd" id="forgotPwd">Forgot Password? </a>
                       </div>
                          <div style="text-align:center; margin-top:20px;">
                           <input type="button" value="Login" id="login" name="login" style="margin-top:20px;" class="btn btn-info">
                          </div>
                    </form>
                   </div>
                 </div>
            </div>
          </div>
           </main>
        </div> 
     </body>
</html>

