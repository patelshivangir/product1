<?php
include('../inc/config.php');
$msg ='';
$id=$_REQUEST['id'];
$res['basicDetail']=[];
$res['images']=[];
$res['options']=[];
$res['values']=[];
//$result[] = [];

if($id > 0){
    
    $sql = "SELECT * FROM `product` WHERE `id` = $id";
    $execute_sql = mysqli_query($con,$sql);
    
    if(mysqli_num_rows($execute_sql) > 0){ 
        
        $value = mysqli_fetch_object($execute_sql);
        $data['id'] = $value->id;
        $data['name']=$value->name;
        $data['sku'] = $value->sku;
        $data['desc'] = $value->description;
        $data['price'] = $value->price;
        $data['stock'] = $value->stock;
        
        array_push($res['basicDetail'],$data);
        //$result[1]=$res['basicDetail'];
    }
        
    $imageSql="SELECT * FROM `tbl_images` WHERE `product_id` = $id";
    $execute_imageSql = mysqli_query($con,$imageSql);
    
    if(mysqli_num_rows($execute_imageSql) > 0){ 
        
        while($val = mysqli_fetch_object($execute_imageSql)){
            $val = $val->image_path;
            array_push($res['images'], $val);
            //array_push($res['images'],$val);
            //$result[2] = $res['images'];
       }
    }
    
    $optionSql="SELECT * FROM `tbl_options` WHERE `product_id` = $id";
    $execute_optionSql = mysqli_query($con,$optionSql);
    
    if(mysqli_num_rows($execute_optionSql) > 0){
        
        while($row = mysqli_fetch_object($execute_optionSql)){
            
            $option['id'] = $row->id;
            $option['title'] = $row->title;
            $option['type'] = $row->type;
            
            array_push($res['options'],$option);
        
            $res['values'][$row->id] = [];
            
            $valueSql="SELECT * FROM `tbl_values` WHERE `option_id`=$row->id";
            $execute_valueSql = mysqli_query($con,$valueSql);
           
           if(mysqli_num_rows($execute_valueSql) > 0){
                
                while($rows = mysqli_fetch_object($execute_valueSql)){
                    
                    $val['id'] = $rows->id;
                    $val['option_id'] = $rows->option_id;
                    $val['title'] = $rows->title;
                    $val['price'] = $rows->price;
                   array_push($res['values'][$row->id], $val);
               }
               
           }
           
           
        }
    }
}

echo json_encode($res);