<?PHP
include('../inc/config.php');

$perPageCount=$_REQUEST['perPageCount'];
$pageNumber = $_REQUEST['pageNumber'];
$searchKey = $_REQUEST['searchKey'];
$condition = '';
$error ='';
$msg[] ='';

if (!isset($pageNumber)) { $pageNumber = 1; } else { $pageNumber = $pageNumber; }

if($searchKey != ''){
   
   $sql = "SELECT * FROM `product` WHERE (`name` LIKE '%".$searchKey."%') OR (`stock` LIKE '%".$searchKey."%') OR (`price` LIKE '%".$searchKey."%') OR (`sku` LIKE '%".$searchKey."%') OR (`description` LIKE '%".$searchKey."%')"; 
}else{
    $sql = "SELECT * FROM `product`";
}

if($row = mysqli_query($con, $sql)){
   $rowCount= mysqli_num_rows($row); 
}
$pagesCount = ceil($rowCount / $perPageCount);

if($pagesCount < $pageNumber){ $pageNumber=1; }

$lowerLimit = ($pageNumber - 1) * $perPageCount;

$sqlQry = "$sql ORDER BY `id` DESC LIMIT ".$lowerLimit.",".$perPageCount;         
$data = mysqli_query($con,$sqlQry);
  ?>
<input type="hidden" name="pagesCount" id="pagesCount" value="<?php echo $pagesCount; ?>">
    <input type="hidden" name="totalRecords" id="totalRecords" value="<?php echo $rowCount; ?>">

<?php if(mysqli_num_rows($data) > 0){ ?>
    
<?php while($row = mysqli_fetch_object($data))
   { 
?>      
        <tr> 
            <td><input class="deleteID" type="checkbox" name="recordID[]" id="delete_<?php echo $row->id; ?>" value="<?php echo $row->id; ?>"></td>
      
            <td> <?php echo $row->name; ?> </td>
            <td> <?php echo $row->sku; ?> </td>
            <td> <?php if($row->stock > 0){ echo "InStock"; }else{ echo "Out Of Stock"; } ?> </td>
            <td> <?php echo $row->stock; ?> </td>
            <td> <?php echo $row->price; ?> </td>
            <td> <?php echo $row->description; ?> </td>
            <td>
                <a name="option" class="btn btn-outline-secondary" href="addProducts.php?id=<?php echo $row->id; ?><?php if(!empty($searchKey)){echo '&q='.$searchKey;} ?>&p=<?php echo $pageNumber; ?>&c=<?php echo $perPageCount; ?>"><i class="fa fa-edit" style="font-size:25px;color:green"></i></a>&nbsp;&nbsp;
                <a href="javascript:void(0)" class="btn btn-outline-secondary" data-toggle="modal" id="deleteConfirm" name="deleteConfirm" onclick="deleteConfirmation('product','<?php echo $row->id; ?>','<?php echo $searchKey; ?>','<?php echo $pageNumber; ?>','<?php echo $perPageCount; ?>')"><i class="fa fa-trash" style="font-size:25px;color:red"></i></a>&nbsp;&nbsp;
            <a name="viewProduct" class="btn btn-outline-secondary" data-toggle="modal" onclick="viewDetail(<?php echo $row->id; ?>)"><i class="fa fa-eye" style="font-size:25px;"></i></a>&nbsp; </td>
                
        </tr>
   <?php  }
} ?>

 