<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="margin-bottom:30px;font-size:15px;">
  <ul class="navbar-nav">
    <li class="nav-item active" style="padding:0px 20px 0px 20px;">
      <a class="nav-link" href="dashbord.php">Dashboard</a>
    </li>
    <li class="nav-item active" style="padding:0px 20px 0px 20px;">
      <a class="nav-link" href="viewProduct.php">Products</a>
    </li>
    <li class="nav-item active" style="padding:0px 20px 0px 20px;">
      <a class="nav-link" href="addProducts.php">Add Product</a>
    </li>
    <li class="nav-item active" style="padding:0px 20px 0px 20px;">
      <a class="nav-link" href="changePwd.php">Change Password</a>
    </li>
    <li class="nav-item active" style="padding:0px 20px 0px 20px;">
      <a class="nav-link" href="logout.php">LogOut</a>
    </li>
    
  </ul>
</nav> 