<?php
//fetch.php






session_start();


// Load pagination class
require_once '/opt/lampp/htdocs/Product/Pagination.class.php';

// Load and initialize database class
require_once '/opt/lampp/htdocs/Product/DB.class.php';
$db = new db();
if(isset($_GET["record"])){
       $record=$_GET["record"];
   
 }
  else{
         $record=5;
     }

$perPageLimit = $record;
$offset = !empty($_GET['page'])?(($_GET['page']-1)*$perPageLimit):0;

 //Get search keyword
$searchKeyword = !empty($_GET['sq'])?$_GET['sq']:'';
$searchStr = !empty($searchKeyword)?'?sq='.$searchKeyword:'';

 //Search DB query
$searchArr = '';
if(!empty($searchKeyword)){
   $searchArr = array(
       'category_name' => $searchKeyword,
        'category_description' => $searchKeyword,
        'category_status' => $searchKeyword
    );
}

 //Get count of the users
$con = array(
    'like_or' => $searchArr,
    'return_type' => 'count'
);
$rowCount = $db->getRows('tbl_category', $con);

 //Initialize pagination class
$pagConfig = array(
    'baseURL' => 'view-category.php'.$searchStr,
    'totalRows' => $rowCount,
    'perPage' => $perPageLimit
);
$pagination = new Pagination($pagConfig);

// Get users from database
$con = array(
    'like_or' => $searchArr,
    'start' => $offset,
    'limit' => $perPageLimit,
    'order_by' => 'category_id ASC',
);
$tbl_category = $db->getRows('tbl_category', $con);



$connect = mysqli_connect("localhost", "root", "", "db_product");
$output = '';


$sq = $_GET['sq'];
if($q != ''){
   
   $sql = "SELECT * FROM `tbl_category` WHERE (`category_name` LIKE '%".$sq."%') OR (`category_description` LIKE '%".$sq."%') OR (`category_status` LIKE '%".$sq."%') OR (`sku` LIKE '%".$sq."%') OR (`parent` LIKE '%".$sq."%')"; 
}else{
    $sql = "SELECT * FROM `tbl_category`";
}
if($row = mysqli_query($con, $sql)){
   $rowCount= mysqli_num_rows($row); 
}

 
$result = mysqli_query($connect, $sql);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
	  <th><input type="checkbox" id="select_all" value=""/><input  type="submit" onClick="return delete_confirm();"  value="delete" >
			</th> 
	  <th>Id</th>
     <th>Category_name</th>
     <th>Description</th>
     <th>Status</th>
     <th>Parent</th>
	 <th>Action</th>
   
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
   <td align="center"><input type="checkbox" name="checked_id[]" class="checkbox" /></td>
   <td>'.$row["category_id"].'</td>
    <td>'.$row["category_name"].'</td>
    <td>'.$row["category_description"].'</td>
    <td>'.$row["category_status"].'</td>
    <td>'.$row["parent"].'</td>
 <td><a href="">Edit </a>|<a href=""> Delete</a></td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}
?>
