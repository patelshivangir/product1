<html>
<head>
<link rel="stylesheet" id="font-awesome-style-css" href="https://www.phpflow.com/code/css/bootstrap3.min.css" type="text/css" media="all">
<!-- jQuery -->
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
</head>
<body>
<div>
<div id="target-content" >loading...</div>
 
<?php
$host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "db_product";
 
    $conn = mysqli_connect($host, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
    /* check connection */
    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }
	//require_once '/opt/lampp/htdocs/Product/Pagination.class.php';
$limit = 2;
$sql = "SELECT COUNT(category_id) FROM tbl_category";  
$rs_result = mysqli_query($conn, $sql);  
$row = mysqli_fetch_row($rs_result);  
$total_records = $row[0];  
$total_pages = ceil($total_records / $limit); 
?>
<div align="center">
<a class='pagination text-center' id="pagination">
<?php if(!empty($total_pages)):for($i=1; $i<=$total_pages; $i++):  
		if($i == 1):?>
            <a class='active'  id="<?php echo $i;?>"><a href='page.php?page=<?php echo $i;?>'><?php echo $i;?></a></a> 
		<?php else:?>
	<a id="<?php echo $i;?>"><a href='page.php?page=<?php echo $i;?>'><?php echo $i;?></a></a></a>
		<?php endif;?>		
<?php endfor;endif;?>  
	</div>
</div>
</body>
<script>
$(document).ready(function() {
$("#target-content").load("page.php?page=1");
    $("#page li").live('click',function(e){
	e.preventDefault();
		$("#target-content").html('loading...');
		$("#pagination li").removeClass('active');
		$(this).addClass('active');
        var pageNum = this.id;
        $("#target-content").load("page.php?page=" + pageNum);
    });
    });
</script>
	<?php /// echo $pagination->createLinks(); ?>