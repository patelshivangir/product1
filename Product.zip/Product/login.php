<?php
    			$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn= mysqli_connect($host,$user,$password,$database);
 
		$email = $_POST["email"];
		$password = $_POST["password"];
 
		if( empty($email) || empty($password) )
		{
			echo "enter email and password";
		}
else
{
		$sql =mysqli_query($conn ,"SELECT count(*) FROM tbl_admin WHERE( email='$email' AND password='$password')");

		$row = mysqli_fetch_row($sql);

		if( $row[0] > 0 )
	
		 echo "Login Successful";
		else
		 echo "Failed To Login";
}
	?>