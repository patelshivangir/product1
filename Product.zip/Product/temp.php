<?php
function fetchCategoryTree($parent = 0, $spacing = '', $user_tree_array = '') {
	
$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn=  mysqli_connect($host,$user,$password,$database);

  if (!is_array($user_tree_array))
    $user_tree_array = array();

   $query =mysqli_query( $conn,"SELECT * FROM tbl_category WHERE parent = $parent ORDER BY category_id ASC")or die(mysqli_error($conn));
   
   
    while ($row = mysqli_fetch_object($query)) {
      $user_tree_array[] = array("category_id" => $row->category_id, "category_name" => $spacing . $row->category_name);
      $user_tree_array = fetchCategoryTree($row->category_id, $spacing . '&nbsp;&nbsp;', $user_tree_array);
    }	
  return $user_tree_array;
}
	
	
$categoryList = fetchCategoryTree();?>

<form>
	<table border="1">

<tr>
		<td>Category</td>
		<td>
			
	<select name='parent'>
<?php foreach($categoryList as $cl) 
{ ?>
  <option value="<?php echo $cl["category_id"] ?>"><?php echo $cl["category_name"]; ?></option>
<?php } 
	
		?></select></td></tr>
	</table>
</form>
