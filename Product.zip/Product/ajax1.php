<?php

$q=$_GET['q'];
echo $q;

?>