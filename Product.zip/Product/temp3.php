
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script></head>
<form method="get">
	<input type="text" id="sq" name="sq">
	<div id="result"></div>
	
	   <script>
            $(document).ready(function(e){
   
	$("#sq").keyup(function()
	{
		$("#result").show();
		var x = $(this).val();
       
		$.ajax ({
				method:'GET',
				url : 'fetch2.php?',
                
				data:'sq='+ x,
				success: function(data)
				{
					$("#result").html(data);
				},
			});
		});
               
	});

        </script>
</form>
</html>