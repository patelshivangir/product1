

<head>
	<script src="jquery.min.js"></script>
<script>
function searchFilter(page_num) {
    page_num = page_num?page_num:0;
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
    $.ajax({
        type: 'GET',
        url: 'getData.php',
        data:'page='+page_num+'&keywords='+keywords+'&sortBy='+sortBy,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success: function (html) {
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
        }
    });
}
</script>
<style>
	div.pagination {
    font-family: "Lucida Sans", Geneva, Verdana, sans-serif;
    padding:20px;
    margin:7px;
}
div.pagination a {
    margin: 2px;
    padding: 0.5em 0.64em 0.43em 0.64em;
    background-color: #ee4e4e;
    text-decoration: none;
    color: #fff;
}
div.pagination a:hover, div.pagination a:active {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #de1818;
    color: #fff;
}
div.pagination span.current {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #f6efcc;
    color: #6d643c;
}
div.pagination span.disabled {
    display:none;
}
	</style>
</head>

<div class="post-search-panel">
    <input type="text" id="keywords" placeholder="Type keywords to filter posts" onkeyup="searchFilter()"/>
    <select id="sortBy" onchange="searchFilter()">
        <option value="">Sort By</option>
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
    </select>
</div>
         Data list table 
    <table border="1">
        <thead>
            <tr>
			  <th><input type="checkbox" id="select_all" value=""/><input  type="submit" onClick="return delete_confirm();"  value="delete" >
			</th> 
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>status</th>
				   <th>Parent</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

<div class="post-wrapper">
   
    <div id="posts_content">
    <?php
    //Include pagination class file
    include('Pagination1.class.php');
    
    //Include database configuration file
    include('dbConfig.php');
    
    $limit = 5;
    
    //get number of rows
    $queryNum = $db->query("SELECT COUNT(*) as category_name FROM tbl_category");
    $resultNum = $queryNum->fetch_assoc();
    $rowCount = $resultNum['category_name'];
    
    //initialize pagination class
    $pagConfig = array(
        'totalRows' => $rowCount,
        'perPage' => $limit,
        'link_func' => 'searchFilter'
    );
    $pagination =  new Pagination($pagConfig);
    
    //get rows
    $query = $db->query("SELECT * FROM tbl_category LIMIT $limit");
    
    if($query->num_rows > 0){ ?>

        <?php
            while($category = $query->fetch_assoc()){ 
                $postID = $category['category_id'];
        ?>
			 <tr>
				<td align="center"><input type="checkbox" name="checked_id[]" class="checkbox" value="<?php echo $category['category_id']; ?>"/></td>      
                <td><?php echo $category['category_id'] ?></td>
                <td><?php echo $category['category_name']; ?></td>
                <td><?php echo $category['category_description']; ?></td>
                <td><?php echo $category['category_status']; ?></td>
				 <td><?php echo $category['parent']; ?></td>
			<?php echo"<td> <a href='edit-category.php?eid={$category['category_id']}'>Edit</a> | <a  Onclick='return ConfirmDelete();' href='view-category.php?did={$category['category_id']}'>Delete</a></td>";?>
               
            </tr>
                    <?php } }else{
            echo " No record found";
	} ?></div>
	</div> 
        </tbody>
    </table>
       
        <?php echo $pagination->createLinks(); ?>
 
