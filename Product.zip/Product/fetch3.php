<?php

$connect = mysqli_connect("localhost", "root", "", "db_product");
$output = '';
//$pageNumber = (int)$_REQUEST['p'];
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM tbl_category 
  WHERE category_Name LIKE '%".$search."%'
  OR category_description LIKE '%".$search."%' 
  OR category_status LIKE '%".$search."%' 
  OR parent LIKE '%".$search."%' 

 ";
}
else
{
 $query = "
  SELECT * FROM tbl_category LIMIT 5
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
 
	 <div class="table-responsive">
   <table class="table table bordered" >
	   <thread class="theme-dark">
    <tr>
	<th><input type="submit" value="delete"  name="delete" onClick="return delete_confirm();">
			<input type="checkbox" id="select_all" value=""/></th> 
	  <th>Id</th>
     <th> Name</th>
     <th>Description</th>
     <th>status</th>
     <th>parent</th>
   
    </tr>
	</thread>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
   <td><input type="checkbox" name="checked_id[]" class="checkbox" value="echo $row["category_id"];"/></td>  
    <td>'.$row["category_id"].'</td>
    <td>'.$row["category_name"].'</td>
    <td>'.$row["category_description"].'</td>
    <td>'.$row["category_status"].'</td>
    <td>'.$row["parent"].'</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>