<?php

// Start session
session_start();


// Load pagination class
require_once '/opt/lampp/htdocs/Product/Pagination.class.php';



// Load and initialize database class
require_once '/opt/lampp/htdocs/Product/DB.class.php';
$db = new db();


// Get session data
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';



// Get status message from session
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}



// Page offset and limit

if(isset($_GET["sq"])){
       $sq=$_GET["sq"];
   
 }
  else{
       
     }

   if(isset($_GET["record"])){
       $record=$_GET["record"];
   
 }
  else{
         $record=5;
     }

$perPageLimit = $record;
$offset = !empty($_GET['page'])?(($_GET['page']-1)*$perPageLimit):0;

 //Get search keyword
$searchKeyword = !empty($_GET['sq'])?$_GET['sq']:'';
$searchStr = !empty($searchKeyword)?'?sq='.$searchKeyword:'';

 //Search DB query
$searchArr = '';
if(!empty($searchKeyword)){
   $searchArr = array(
       'category_name' => $searchKeyword,
        'category_description' => $searchKeyword,
        'category_status' => $searchKeyword
    );
}

 //Get count of the users
$con = array(
    'like_or' => $searchArr,
    'return_type' => 'count'
);
$rowCount = $db->getRows('tbl_category', $con);

 //Initialize pagination class
$pagConfig = array(
    'baseURL' => 'view-category.php'.$searchStr,
    'totalRows' => $rowCount,
    'perPage' => $perPageLimit
);
$pagination = new Pagination($pagConfig);

// Get users from database
$con = array(
    'like_or' => $searchArr,
    'start' => $offset,
    'limit' => $perPageLimit,
    'order_by' => 'category_id ASC',
);
$tbl_category = $db->getRows('tbl_category', $con);

?>

<!-- Display status message -->
<?php if(!empty($statusMsg) && ($statusMsgType == 'success')){ ?>
<div class="alert alert-success"><?php echo $statusMsg; ?></div>
<?php }elseif(!empty($statusMsg) && ($statusMsgType == 'error')){ ?>
<div class="alert alert-danger"><?php echo $statusMsg; ?></div>
<?php } ?>

<html>
	<head>
		   
		<style>
/* menu and sub menu  */	
            table {  
    color: #333;
    font-family: Helvetica, Arial, sans-serif;
    width: 100%; 
    border:1px; 
}

td, th {  
    border: 1px ; /* No more visible border */
    height: 30px; 
    transition: all 0.3s;  /* Simple transition for hover effect */
}

th {  
    background: #DFDFDF;  /* Darken header a bit */
    font-weight: bold;
}

td {  
    background: #FAFAFA;
    text-align: center;
}
body{
	margin:2%;
	background:#f2f2f2;
    border:200px; 
	}
.nav{
	width:100%;
	background:#000033;
	height:80px;
		}
			
	form {
  border: 3px solid #f1f1f1;
		
		margin:0;
		
}


				
ul{
	list-style:none;
	padding:0;
	margin:0;
	position:relative;
			}
ul li{
	float:left;
	margin-top:20px;
				}
ul li a{
	width:150px;
	color:white;
	display:block;
	text-decoration:none;
	font-size:20px;
	text-align:center;
	padding:10px;
	border-radius:10px;
	font-family:Century Gothic;
	font-weight:bold;
				}

ul li ul{
	background:#000033;}
ul li ul li{
	float:none;
		}
ul li ul{
	display:none;
	
	}
ul li:hover ul{
	display:block;
	overflow:hide;
				}
/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
        .sub {
	margin: 1em 0 0.5em 0;
	font-weight: 100;
	font-family: 'Titillium Web', sans-serif;
	position: relative;  
	font-size: 12px;
	line-height: 10px;
	padding: 15px 15px 15px 15%;
	color: #355681;
	border-radius: 10px 10px 10px 10px;
	
}
     .search
            {
            
                	margin: 1em 0 0.5em 0;
                position: relative; 
            }
            
	.btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 10px 20px;
  font-size: 12px;
  cursor: pointer;
}

/* Green */
.success {
  border-color: #4CAF50;
  color: green;
}

.success:hover {
  background-color: #4CAF50;
  color: white;
}
                        /* Blue */
.info {
  border-color: #2196F3;
  color: dodgerblue
}

.info:hover {
  background: #2196F3;
  color: white;
}

/* Orange */
.warning {
  border-color: #ff9800;
  color: orange;
}

.warning:hover {
  background: #ff9800;
  color: white;
}
        </style>

<style>
	div.pagination {
    font-family: "Lucida Sans", Geneva, Verdana, sans-serif;
    padding:20px;
    margin:7px;
}
div.pagination a {
    margin: 2px;
    padding: 0.5em 0.64em 0.43em 0.64em;
    background-color: #4CAF50;
    text-decoration: none;
    color: #fff;
}
div.pagination a:hover, div.pagination a:active {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #4CAF50;
    color: #fff;
}
div.pagination span.current {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #f6efcc;
    color: #6d643c;
}
div.pagination span.disabled {
    display:none;
}
	</style>
		</head>
	<body>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script type="text/javascript">
            
			function ConfirmDelete()
			{
				var x=confirm("are you sure you want to delete");
			if(x)
			{
				return true;
			}
				else
				{
					return false;
				}
			}
		</script>
        <script>
            $(document).ready(function(e){
   
	$("#sq").keyup(function()
	{
		$("#here").show();
		var x = $(this).val();
       
		$.ajax ({
				method:'GET',
				url : 'ajaxa.php?',
                
				data:'sq='+ x,
				success: function(data)
				{
					$("#here").html(data);
				},
			});
		});
               
	});

        </script>
	
		<script>
		$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
	
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});
		</script>
        <script src="jquery.min.js"></script>
	
		<div class="nav">
			<ul>
				<li><a href="Dashboard.php">Dashboard</a></li>
				
				<li><a href="add-category.php">Add category</a></li> 
				<li><a href="view-category.php">View category</a></li>
			
					<li><a href="add-product-details.php">Add Product</a></li>
				<li><a href="view-product.php">View Product</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
	</div>	
        		<?php if(!empty($statusMsg) && ($statusMsgType == 'success')){ ?>
<div class="alert alert-success"><?php echo $statusMsg; ?></div>
<?php }elseif(!empty($statusMsg) && ($statusMsgType == 'error')){ ?>
<div class="alert alert-danger"><?php echo $statusMsg; ?></div>
<?php } ?>
                    

            <?php

			if(isset($_GET['message']))
			{
				$message=$_GET['message'];
				
		if($message)
		{
			echo $_GET['message'];
		}
			}
        else
        {
        }
             ?>


		      <form method="get" action=""  >
		  <div class="container">
        	<br><br><br><br>
              <div class="sub">
				<h1> View Category</h1>
              </div>
                   <Button type="button"  class="btn warning" onclick="window.location='view-category.php'">Refresh
			</Button>
              <br><br>
                
            <!--  <div class="search">
      <input type="search" name="sq"  placeholder="Search by keyword..." >
              <input type="submit" class="btn success" name="submit" value="search">-->
              <label>Search <input type="text"  name="sq"   placeholder="Search by keyword..." id="sq" value="<?php if(isset($sq)){ echo $q;} ?>"/></label>
	       <div id="here"></div>
            
         
			</div>
                  
          <!--    </div>-->
       
          <br><br>

			
            <?php
			$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn= mysqli_connect($host,$user,$password,$database);
            
            
            
            			
	if(isset($_GET['delete'])){
        $checkbox=$_GET['delete'];
        
	$checkbox = $_GET['checked_id'];
	for($i=0;$i<count($checkbox);$i++){
	$del_id = $checkbox[$i]; 
	mysqli_query($conn,"DELETE FROM tbl_category WHERE category_id='".$del_id."'");
	
	$message = "Data deleted successfully !";
}
}
            
            
			if(isset($_GET['did']))
			{
				$did=$_GET['did'];
				$query= mysqli_query($conn,"delete from tbl_category where category_id='{$did}'");
		if($query)
		{
			//echo "<script>alert('Record deleted')</script>";
		}
			}
               ?> <table border="1">
        <thead>
            <tr>
			  <th><input type="submit" value="delete"  name="delete" onClick='return delete_confirm();'>
			<input type="checkbox" id="select_all" value=""/></th> 
                <th>#</th>
				
			
                <th>CategoryName</th>
                <th>Description</th>
                <th>Status</th>
                <th>Parent</th>
                <th>Action</th>
            </tr>
        </thead>
     
    </table>
	
			
          
          
      
                   <select name="record"  onchange="valueselect(this.value);">
                <option value="5" selected> <a href="view-category.php?id=<?php echo $record; ?>">5</a></option>
                  <option value="10" ><a href="view-category.php?id=<?php echo $record; ?>">10</a></option>
                      <option value="20" ><a href="view-category.php?id=<?php echo $record; ?>">20</a></option>
                 </select>
                    <input type="submit" >
 </form>
		<br><br>	  		
      
		
	</body>
</html>
    <!-- Display pagination links -->
    <?php  echo $pagination->createLinks(); ?>