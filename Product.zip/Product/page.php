<html>

<head>
<script>
    $(function () {
        $("#submit").click(function () {
            var getValue = $("#email").val();

            if (getValue == "ok") {
                $('#form1').submit();
            } else {
                alert('no validate');
            }
        });
    });
</script>
</head>
<body>
<form id="form1" name="form1">
	<h2> Login</h2>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" id="email" name="email" >

  

    <button type="submit"  name="submit" value="submit">Sign In</button>
	  <button type="reset" class="cancelbtn" value="validate">Cancel</button>
<br>
	
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
	      

</form>
</body>
</html>