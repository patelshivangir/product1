<?php
$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn= mysqli_connect($host,$user,$password,$database);
session_start();
$editid=$_GET['eid'];
$selectq=mysqli_query($conn,"select *from tbl_product where product_id='{$editid}'")or die(mysqli_error($conn));
$row =mysqli_fetch_array($selectq);

// Get session data
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';

// Get status message from session
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
if($_POST)
	
{

		$parent= $_POST['parent'];
	 	$product_name=$_POST['product_name'];
		$destination= "images/".$_FILES['product_images']['name'];
		$product_description=$_POST['product_description'];
		$product_price=$_POST['product_price'];
		$product_quantity=$_POST['product_quantity'];
	//	$source= $_FILES['product_images']['tmp_name'];
	
	
	$updateq=mysqli_query($conn,"update tbl_product set category_id='{$parent}',product_name='{$product_name}',product_images='{$destination}',product_description='{$product_description}',product_price='{$product_price}',product_quantity='{$product_quantity}'  where product_id='{$editid}'")or die(mysqli_error($conn));
if($updateq)
{



	 $u = '<span  style="text-align:center; color:green; font-size:30px;">Update record successfully !!!</span>';
    header("Location:view-product.php?message=".$u);
    exit();

}
	
}


  // drop down in tree view
function fetchCategoryTree($parent = 0, $spacing = '', $user_tree_array = '') {
	
$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn=  mysqli_connect($host,$user,$password,$database);

  if (!is_array($user_tree_array))
    $user_tree_array = array();

   $query =mysqli_query( $conn,"SELECT * FROM tbl_category WHERE parent = $parent ORDER BY category_id ASC")or die(mysqli_error($conn));
   
   
    while ($row = mysqli_fetch_object($query)) {
      $user_tree_array[] = array("category_id" => $row->category_id, "category_name" => $spacing . $row->category_name);
      $user_tree_array = fetchCategoryTree($row->category_id, $spacing . '&nbsp;&nbsp;', $user_tree_array);
    }
  
  return $user_tree_array;
}
	
	
$categoryList = fetchCategoryTree();


?>
<html>
	<head>
		<style>
	.btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 10px 20px;
  font-size: 12px;
  cursor: pointer;
}

/* Green */
.success {
  border-color: #4CAF50;
  color: green;
}
.msg
			{
				color:red;
				font-size:20px;
			}
			
.success:hover {
  background-color: #4CAF50;
  color: white;
}

			            table {  
    Background-color: #e6e6e6;
	margin:05%;
			}


body{
	margin:2%%;
	background:#f2f2f2;
    border:200px; 
	}
.nav{
	width:100%;
	background:#000033;
	height:80px;
		}
			
	form {
  border: 3px solid #f1f1f1;
		
		margin:0;
		
}


				
ul{
	list-style:none;
	padding:0;
	margin:0;
	position:relative;
			}
ul li{
	float:left;
	margin-top:20px;
				}
ul li a{
	width:150px;
	color:white;
	display:block;
	text-decoration:none;
	font-size:20px;
	text-align:center;
	padding:10px;
	border-radius:10px;
	font-family:Century Gothic;
	font-weight:bold;
				}

ul li ul{
	background:#000033;}
ul li ul li{
	float:none;
		}
ul li ul{
	display:none;
	
	}
ul li:hover ul{
	display:block;
	overflow:hide;
				}
/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
			      .sub {
	margin: 1em 0 0.5em 0;
	font-weight: 100;
	font-family: 'Titillium Web', sans-serif;
	position: relative;  
	font-size: 12px;
	line-height: 10px;
	padding: 15px 15px 15px 15%;
	color: #355681;
	border-radius: 10px 10px 10px 10px;
	
}
		</style>
	</head>
	<body>
			
		<div class="nav">
	<ul>
				<li><a href="Dashboard.php">Dashboard</a></li>
				
				<li><a href="add-category.php">Add category</a></li> 
				<li><a href="view-category.php">View category</a></li>
			
					<li><a href="add-product-details.php">Add Product</a></li>
				<li><a href="view-product.php">View Product</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
	</div>		
		<br>
		<?php if(!empty($statusMsg) && ($statusMsgType == 'success')){ ?>
<div class="alert alert-success"><?php echo $statusMsg; ?></div>
<?php }elseif(!empty($statusMsg) && ($statusMsgType == 'error')){ ?>
<div class="alert alert-danger"><?php echo $statusMsg; ?></div>
<?php } ?>

<form method="post" enctype="multipart/form-data">
	<br>			<br>
	<div class="sub">
		<h1>Edit Product</h1></div>
<table border="1">
<tr>
		<td>Category</td>
		<td>
	<select name='parent'>
<?php foreach($categoryList as $cl) { ?>
  <option value="<?php echo $cl["category_id"] ?>"><?php echo $cl["category_name"]; ?></option>
<?php } 
	
		?></select></td></tr>
	
<tr>

<tr>
<td>Product Name</td>
<td><input type="text" name="product_name" required value="<?php echo $row['product_name']; ?>"></td>
	</tr>
	<tr>
<td>Product Images</td>
<td><input type="file" name="product_images" value="<?php  echo $row['product_images'];?>"  ></td>
	</tr>
	<tr>
<td>Description:</td>
<td><input type="textarea"  name="product_description" value="<?php echo $row['product_description'];?>" ></td>
	</tr>
	<tr>
<td>Product Quantity:</td>
<td><input type="number"  name="product_quantity" value="<?php echo $row['product_quantity'];?>"></td>
	</tr>
	<tr>
<td>Product Price:</td> 
<td><input type="number"  name="product_price" value="<?php echo $row['product_price'];?>"></td>
	</tr>
		<tr>
		<td></td>
		<td><input type="submit" class="btn success" name="submit" value="Submit">
		<input type="button" name="view" class="btn success" value="View" onclick="window.location='view-product.php'"></td>
	</tr>
 <?php if(isset($_POST['msg']))
  echo $_POST['msg'];
  ?>
</table>
</form>
	</body>
	</html>