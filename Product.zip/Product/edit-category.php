<?php
$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn= mysqli_connect($host,$user,$password,$database);
session_start();
$editid=$_GET['eid'];
$selectq=mysqli_query($conn,"select *from tbl_category where category_id='{$editid}'")or die(mysqli_error($conn));
$categoryrow= mysqli_fetch_array($selectq);

// Get session data
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';

// Get status message from session
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
if($_POST)
{

	$parent= $_POST['parent'];
	 $category_name=$_POST['category_name'];
		 $category_description=$_POST['category_description'];
	$group1=$_POST['group1'];
	
	
	$updateq=mysqli_query($conn,"update tbl_category set parent='{$parent}',category_name='{$category_name}',category_description='{$category_description}',category_status='{$group1}' where category_id='{$editid}'")or die(mysqli_error($conn));

	if($updateq==true)
	{

	 $u = '<span  style="text-align:center; color:green; font-size:30px;">Update record successfully !!!</span>';
    header("Location:view-category.php?message=".$u);
    exit();
	}

}
		


  // drop down in tree view
function fetchCategoryTree($parent = 0, $spacing = '', $user_tree_array = '') {
	
$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn=  mysqli_connect($host,$user,$password,$database);

  if (!is_array($user_tree_array))
    $user_tree_array = array();

   $query =mysqli_query( $conn,"SELECT * FROM tbl_category WHERE parent = $parent ORDER BY category_id ASC")or die(mysqli_error($conn));
   
   
    while ($row = mysqli_fetch_object($query)) {
      $user_tree_array[] = array("category_id" => $row->category_id, "category_name" => $spacing . $row->category_name);
      $user_tree_array = fetchCategoryTree($row->category_id, $spacing . '&nbsp;&nbsp;', $user_tree_array);
    }
  
  return $user_tree_array;
}
	
	
$categoryList = fetchCategoryTree();
?><html>
	<head>
		<style>
			
	.btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 10px 20px;
  font-size: 12px;
  cursor: pointer;
}

/* Green */
.success {
  border-color: #4CAF50;
  color: green;
}

.success:hover {
  background-color: #4CAF50;
  color: white;
}
			     
				            table {  
    Background-color: #e6e6e6;
	margin:05%;
			}
body{
	margin:2%%;
	background:#f2f2f2;
    border:200px; 
	}
.nav{
	width:100%;
	background:#000033;
	height:80px;
		}
			
		
}


				
ul{
	list-style:none;
	padding:0;
	margin:0;
	position:relative;
			}
ul li{
	float:left;
	margin-top:20px;
				}
ul li a{
	width:150px;
	color:white;
	display:block;
	text-decoration:none;
	font-size:20px;
	text-align:center;
	padding:10px;
	border-radius:10px;
	font-family:Century Gothic;
	font-weight:bold;
				}

ul li ul{
	background:#000033;}
ul li ul li{
	float:none;
		}
ul li ul{
	display:none;
	
	}
ul li:hover ul{
	display:block;
	overflow:hide;
				}
/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
			      .sub {
	margin: 1em 0 0.5em 0;
	font-weight: 100;
	font-family: 'Titillium Web', sans-serif;
	position: relative;  
	font-size: 12px;
	line-height: 10px;
	padding: 15px 15px 15px 15%;
	color: #355681;
	border-radius: 10px 10px 10px 10px;
	
}
		</style>
	</head>
	<body>
			
		<div class="nav">
	<ul>
				<li><a href="Dashboard.php">Dashboard</a></li>
				
				<li><a href="add-category.php">Add category</a></li> 
				<li><a href="view-category.php">View category</a></li>
			
					<li><a href="add-product-details.php">Add Product</a></li>
				<li><a href="view-product.php">View Product</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
	</div>		
		<br>
				<?php if(!empty($statusMsg) && ($statusMsgType == 'success')){ ?>
<div class="alert alert-success"><?php echo $statusMsg; ?></div>
<?php }elseif(!empty($statusMsg) && ($statusMsgType == 'error')){ ?>
<div class="alert alert-danger"><?php echo $statusMsg; ?></div>
<?php } ?>
<form method="post" enctype="multipart/form-data">
	<br>			<br><br>
	<div class="sub">
		<h1>Edit Category</h1></div>
<table border="1">

<tr>
	<td>category</td>
	<td><select name='parent'>
<?php foreach($categoryList as $cl) { ?>
  <option value="<?php echo $cl["category_id"] ?>"><?php echo $cl["category_name"]; ?></option>
<?php } 
	
		?></select></td></tr>
    <tr>
<td>Category Id</td>
<td><input type="hidden" name="category_id"  value="<?php echo $categoryrow['category_id']; ?>"></td>
	</tr>
<tr>
<td>Category Name</td>
<td><input type="text" name="category_name"  value="<?php echo $categoryrow['category_name']; ?>"></td>
	</tr>
	<tr>
<td>Description:</td>
<td><input type="textarea"  name="category_description" value="<?php echo $categoryrow['category_description']; ?>" ></td>
	</tr>
	<tr>
<td>Category Status:</td>
<td>Enable<input type="radio"  name="group1" value="enable"<?php if($categoryrow['category_status']== "enable"){echo "checked";} ?>>
	Disable	<input type="radio" name="group1" value="disable"<?php if($categoryrow['category_status']== "disable"){echo "checked";} ?>></td>
	</tr>
		<tr>
		<td></td>
		<td><input type="submit" class="btn success" name="submit" value="Submit">
		<input type="button" name="view" class="btn success" value="View" onclick="window.location='view-category.php'"></td>
	</tr>

</table>
</form>
	</body>
</html>
	