<?php
session_start();
if(session_destroy())
{
		echo "Logout";
	header("location:index.php");

}
?>