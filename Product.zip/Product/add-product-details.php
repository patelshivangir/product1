<?php
$host="localhost";
$user="root";
$password="";
$database="db_product";

$connection= mysqli_connect($host,$user,$password,$database);
session_start();
//$msg='';
if($_POST)
{
	
	$parent= $_POST['parent'];
	$product_name= $_POST['product_name'];
	//$source= $_FILES['product_images']['tmp_name'];
	$destination= "images/".$_FILES['product_images']['name'];

	$product_description=$_POST['product_description'];
	$product_quantity=$_POST['product_quantity'];
	$product_price=$_POST['product_price'];

	$query=mysqli_query($connection, "insert into tbl_product (category_id,product_name,product_images,product_description,product_quantity,product_price) values ('{$parent}','{$product_name}','{$destination}','{$product_description}','{$product_quantity}','{$product_price}')") or die(mysqli_error($connection));
	if($query)
	{

		//$fileprocess= move_uploaded_file($_FILES['product_images']['tmp_name'],$destination);
	//}
	//if($fileprocess)
	//{
				//$msg ='<div class="alert alert-sucess" role="alert">Record Update</div>'
		echo "<script>alert('Record Inserted')</script>";

	}
	

}


   // drop down in tree view
function fetchCategoryTree($parent = 0, $spacing = '', $user_tree_array = '') {
	
$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn=  mysqli_connect($host,$user,$password,$database);

  if (!is_array($user_tree_array))
    $user_tree_array = array();

   $query =mysqli_query( $conn,"SELECT * FROM tbl_category WHERE parent = $parent ORDER BY category_id ASC")or die(mysqli_error($conn));
   
   
    while ($row = mysqli_fetch_object($query)) {
      $user_tree_array[] = array("category_id" => $row->category_id, "category_name" => $spacing . $row->category_name);
      $user_tree_array = fetchCategoryTree($row->category_id, $spacing . '&nbsp;&nbsp;', $user_tree_array);
    }	
  return $user_tree_array;
}
	
	
$categoryList = fetchCategoryTree();?>

<html>
<head>
	<script type="text/javascript" language="javascript" src="js/dashboard.js"></script>
		<style>
/* menu and sub menu  */	

.nav{
	width:100%;
	background:#000033;
	height:80px;
	

		}
	            table {  
    Background-color: #e6e6e6;
	margin:05%;
			}
				
ul{
	list-style:none;
	padding:0;
	margin:0;
	position:relative;
			}
ul li{
	float:left;
	margin-top:20px;
				}
ul li a{
	width:150px;
	color:white;
	display:block;
	text-decoration:none;
	font-size:20px;
	text-align:center;
	padding:10px;
	border-radius:10px;
	font-family:Century Gothic;
	font-weight:bold;
				}
a:hover{
	background:#669900;
		}
ul li ul{
	background:#000033;}
ul li ul li{
	float:none;
		}
ul li ul{
	display:none;
	
	}
ul li:hover ul{
	display:block;
	overflow:hide;
				}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
	     .sub {
	margin: 1em 0 0.5em 0;
	font-weight: 100;
	font-family: 'Titillium Web', sans-serif;
	position: relative;  
	font-size: 12px;
	line-height: 10px;
	padding: 10px 10px 10px 10%;
	color: #355681;
	border-radius: 10px 10px 10px 10px;
	
}
	.btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 10px 20px;
  font-size: 12px;
  cursor: pointer;
}

/* Green */
.success {
  border-color: #4CAF50;
  color: green;
}

.success:hover {
  background-color: #4CAF50;
  color: white;
}
	</style>
<title></title>
</head>
<body>
	<div class="nav">
		<ul>
				<li><a href="Dashboard.php">Dashboard</a></li>
				
				<li><a href="add-category.php">Add category</a></li> 
				<li><a href="view-category.php">View category</a></li>
			
					<li><a href="add-product-details.php">Add Product</a></li>
				<li><a href="view-product.php">View Product</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
	</div>	
<form method="get" enctype="multipart/form-data">
	<br>			<br><br>
	<div class="sub">
		<h1>Add Product</h1></div>
	 
   <div class="table-responsive">
            <table class="table table-bordered">
         

<tr>
		<td>Category</td>
		<td>
			
	<select name='parent'>
<?php foreach($categoryList as $cl) 
{ ?>
  <option value="<?php echo $cl["category_id"] ?>"><?php echo $cl["category_name"]; ?></option>
<?php } 
	
		?></select></td></tr>
	
<tr>
<td>Product Name</td>
<td><input type="text" name="product_name" required="true" value=""></td>
	</tr>
	<tr>
<td>Product Images</td>
<td><input type="file" name="product_images" multiple required="true"  ></td>
	</tr>
	<tr>
<td>Description:</td>
<td><input type="textarea" required="true" name="product_description" ></td>
	</tr>
	<tr>
<td>Product Quantity:</td>
<td><input type="number"  required="true" name="product_quantity"></td>
	</tr>
	<tr>
<td>Product Price:</td>
<td><input type="number" required="true" name="product_price"></td>
	
	</tr>
		<tr>
		<td></td>
		<td><input type="submit" class="btn success" name="submit" value="Submit">
		<input type="button" class="btn success" name="view" value="View" onclick="window.location='view-product.php'"></td>
	</tr>
				
				
</table>
	</div>
</form>
</body>
</html>