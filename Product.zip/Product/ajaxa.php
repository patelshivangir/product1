<html>
<head>
</head>
<body>



</body>
</html>
<?php
session_start();


// Load pagination class
require_once '/opt/lampp/htdocs/Product/Pagination.class.php';



// Load and initialize database class
require_once '/opt/lampp/htdocs/Product/DB.class.php';
$db = new db();


// Get session data
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';



// Get status message from session
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}



// Page offset and limit

if(isset($_GET["sq"])){
       $sq=$_GET["sq"];
   
 }
  else{
       
     }

   if(isset($_GET["record"])){
       $record=$_GET["record"];
   
 }
  else{
         $record=5;
     }

$perPageLimit = $record;
$offset = !empty($_GET['page'])?(($_GET['page']-1)*$perPageLimit):0;

 //Get search keyword
$searchKeyword = !empty($_GET['sq'])?$_GET['sq']:'';
$searchStr = !empty($searchKeyword)?'?sq='.$searchKeyword:'';

 //Search DB query
$searchArr = '';
if(!empty($searchKeyword)){
   $searchArr = array(
       'category_name' => $searchKeyword,
        'category_description' => $searchKeyword,
        'category_status' => $searchKeyword
    );
}

 //Get count of the users
$con = array(
    'like_or' => $searchArr,
    'return_type' => 'count'
);
$rowCount = $db->getRows('tbl_category', $con);

 //Initialize pagination class
$pagConfig = array(
    'baseURL' => 'view-category.php'.$searchStr,
    'totalRows' => $rowCount,
    'perPage' => $perPageLimit
);
$pagination = new Pagination($pagConfig);

// Get users from database
$con = array(
    'like_or' => $searchArr,
    'start' => $offset,
    'limit' => $perPageLimit,
    'order_by' => 'category_id ASC',
);
$tbl_category = $db->getRows('tbl_category', $con);


$host="localhost";
$user="root";
$password="";
$database="db_product";

$con= mysqli_connect($host,$user,$password,$database);
//$result=mysqli_query( $con,"select * from tbl_category");
   if(isset($_GET["data"])){
       $data=$_GET["data"];
   
 }
  else{
        $result=mysqli_query( $con,"select * from tbl_category");
     }

	
			$result=mysqli_query( $con,"select * from tbl_category where category_name LIKE '%$sq%'");?>
			 <table border="1" id="data">
        <thead>
            <tr>
			  <th><input type="checkbox" id="select_all" value=""/><input  type="submit" onClick="return delete_confirm();" value="delete" >
			</th> 
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>status</th>
				   <th>Parent</th>
                <th>Action</th>
            </tr>
        </thead>
  <tr>
				 <?php
     while ($row = mysqli_fetch_assoc($result)) {?>
				<td align="center"><input type="checkbox" name="checked_id[]" class="checkbox" value="<?php echo $category['category_id']; ?>"/></td>      
                <td><?php echo $row['category_id'] ?></td>
                <td><?php echo $row['category_name']; ?></td>
                <td><?php echo $row['category_description']; ?></td>
                <td><?php echo $row['category_status']; ?></td>
				 <td><?php echo $row['parent']; ?></td>
			<?php echo"<td> <a href='edit-category.php?eid={$row['category_id']}'>Edit</a> | <a  Onclick='return ConfirmDelete();' href='view-category.php?did={$row['category_id']}'>Delete</a></td>";?>
           
            </tr>
<?php
}

		
			
        
 ?>





 

	  
