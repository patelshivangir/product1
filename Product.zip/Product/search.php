
<?php
			$host="localhost";
$user="root";
$password="";
$database="db_product";

$conn= mysqli_connect($host,$user,$password,$database);
//$pageNumber = (int)$_REQUEST['p'];
if(isset($_GET["showRecordPerPage"])){
       $showRecordPerPage=$_GET["showRecordPerPage"];
   
 }
  else{
         $showRecordPerPage=5;
     }
$showRecordPerPage = $showRecordPerPage;
if(isset($_GET['page']) && !empty($_GET['page'])){
$currentPage = $_GET['page'];
}else{
$currentPage = 1;
}
$startFrom = ($currentPage * $showRecordPerPage) - $showRecordPerPage;
$totalsql = "SELECT * FROM tbl_category";
$totalresult = mysqli_query($conn, $totalsql);
$total = mysqli_num_rows ($totalresult);
$lastPage = ceil($total/$showRecordPerPage);
$firstPage = 1;
$nextPage = $currentPage + 1;
$previousPage = $currentPage - 1;
$sql = "SELECT *
FROM `tbl_category` LIMIT $startFrom, $showRecordPerPage";
$result = mysqli_query($conn, $sql);

?><html>
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	 	<style>
/* menu and sub menu  */	
            table {  
    color: #333;
    font-family: Helvetica, Arial, sans-serif;
    width: 100%; 
    border:1px; 
}

td, th {  
    border: 1px ; /* No more visible border */
    height: 30px; 
    transition: all 0.3s;  /* Simple transition for hover effect */
}

th {  
    background: #DFDFDF;  /* Darken header a bit */
    font-weight: bold;
}

td {  
    background: #FAFAFA;
    text-align: center;
}
body{
	margin:2%;
	background:#f2f2f2;
    border:200px; 
	}
.nav{
	width:100%;
	background:#000033;
	height:80px;
		}
			
	form {
  border: 3px solid #f1f1f1;
		
		margin:0;
		
}


				
ul{
	list-style:none;
	padding:0;
	margin:0;
	position:relative;
			}
ul li{
	float:left;
	margin-top:20px;
				}
ul li a{
	width:150px;
	color:white;
	display:block;
	text-decoration:none;
	font-size:20px;
	text-align:center;
	padding:10px;
	border-radius:10px;
	font-family:Century Gothic;
	font-weight:bold;
				}

ul li ul{
	background:#000033;}
ul li ul li{
	float:none;
		}
ul li ul{
	display:none;
	
	}
ul li:hover ul{
	display:block;
	overflow:hide;
				}
/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
		.page-link
		{
			  background-color: #4CAF50;
				width=20%;
				font-size: 12px;
		}
        .sub {
	margin: 1em 0 0.5em 0;
	font-weight: 100;
	font-family: 'Titillium Web', sans-serif;
	position: relative;  
	font-size: 12px;
	line-height: 10px;
	padding: 15px 15px 15px 15%;
	color: #355681;
	border-radius: 10px 10px 10px 10px;
	
}
     .search
            {
            
                	margin: 1em 0 0.5em 0;
                position: relative; 
            }
            
	.btn {
  border: 2px solid black;
  background-color: white;
  color: black;
  padding: 10px 20px;
  font-size: 12px;
  cursor: pointer;
}

/* Green */
.success {
  border-color: #4CAF50;
  color: green;
}

.success:hover {
  background-color: #4CAF50;
  color: white;
}
                        /* Blue */
.info {
  border-color: #2196F3;
  color: dodgerblue
}

.info:hover {
  background: #2196F3;
  color: white;
}

/* Orange */
.warning {
  border-color: #ff9800;
  color: orange;
}

.warning:hover {
  background: #ff9800;
  color: white;
}
        </style>

 <style>
	div.pagination {
    font-family: "Lucida Sans", Geneva, Verdana, sans-serif;
    padding:20px;
    margin:7px;
}
div.pagination a {
    margin: 2px;
    padding: 0.5em 0.64em 0.43em 0.64em;
    background-color: #4CAF50;
    text-decoration: none;
    color: #fff;
}
div.pagination a:hover, div.pagination a:active {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #4CAF50;
    color: #fff;
}
div.pagination span.current {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #f6efcc;
    color: #6d643c;
}
div.pagination span.disabled {
    display:none;
}
	</style>
 </head>
 <body>
	 	<div class="nav">
			<ul>
				<li><a href="Dashboard.php">Dashboard</a></li>
				<li><a href="add-category.php">Add category</a></li> 
				<li><a href="view-category.php">View category</a></li>
				<li><a href="add-product-details.php">Add Product</a></li>
				<li><a href="view-product.php">View Product</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
	</div>	
	 <input type="hidden" id="pageNumber" value="<?php if($pageNumber > 0){ echo $pageNumber; } ?>">
  <div class="container">
   <div class="form-group">
  	 <div class="sub">
                  <h1> View category</h1></div>
              
             <label>show </label>
                 <select name="showRecordPerPage" onchange="this.form.submit()">
                <option value="5" selected> <a href="view-product.php?id=<?php echo $record; ?>">5</a></option>
                  <option value="10" ><a href="view-product.php?id=<?php echo $record; ?>">10</a></option>
                      <option value="20" ><a href="view-product.php?id=<?php echo $record; ?>">20</a></option>
                 </select>
          <Button type="button"  class="btn warning" onclick="window.location='search.php'">Refresh
			</Button>   
  
    <div class="input-group">
		<label>Search</label>
     <input type="text" name="search_text" id="search_text"  class="form-control" />
    </div>
   </div>
   <br />
   <div id="result"></div>
	 
  </div>
	  <label> Total Record: </label> 	<?php echo $total;?> | <?php echo $showRecordPerPage; ?>
	 <nav aria-label="Page navigation">
		
<ul class="pagination">
	
<?php if($currentPage != $firstPage) { ?>

<li class="page-item">
	
<a class="page-link" href="?page=<?php echo $firstPage ?>" tabindex="-1" aria-label="Previous">
<span aria-hidden="true">First</span>
</a>
</li>
<?php } ?>
<?php if($currentPage >= 2) { ?>
<li class="page-item"><a class="page-link" href="?page=<?php echo $previousPage ?>"><?php echo $previousPage ?></a></li>
<?php } ?>
<li class="page-item active"><a class="page-link" href="?page=<?php echo $currentPage ?>"><?php echo $currentPage ?></a></li>
<?php if($currentPage != $lastPage) { ?>
<li class="page-item"><a class="page-link" href="?page=<?php echo $nextPage ?>"><?php echo $nextPage ?></a></li>
<li class="page-item">
<a class="page-link" href="?page=<?php echo $lastPage ?>" aria-label="Next">
<span aria-hidden="true">Last</span>
</a>
</li>
<?php } ?>
</ul>
	
</nav>
 </body>
</html>


<script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch3.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>