
        <link rel="stylesheet" href="css/bootstrap.min.css">

        <script type="text/javascript" src="css/jquery.min.js"></script> 

        <script src="css/popper.min.js"></script>

        <script src="css/bootstrap.min.js"></script>

        <link rel="stylesheet" href="css/style.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/fontawesome.min.css">

