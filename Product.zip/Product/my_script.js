$("button#submit").click( function() {
 
  if( $("#email").val() == "" || $("#password").val() == "" )
    $("div#ack").html("Please enter both email and password");
  else
    $.post( $("#myForm").attr("action"),
	        $("#myForm :input").serializeArray(),
			function(data) {
			  $("div#ack").html(data);
			});
 
	$("#myForm").submit( function() {
	   return false;	
	});
 