<?PHP
include('config.php');

$email = $_REQUEST['email'];
$password = $_REQUEST['password'];

$error ='';
$msg[] ='';

if($email == ''){ $error .= "Email is required"; }

if($password == ''){ $error .= "Password is required"; }

if($error == ''){
    
    if($email != '' && $password != ''){
        $password = md5($password);
        $sql = "SELECT * FROM `tbl_admin` WHERE `email`='".$email."' && `password`='".$password."'";            
        $data = mysqli_query($con,$sql);
        
        if(mysqli_num_rows($data) > 0){
            
           $row = mysqli_fetch_object($data);
           $_SESSION['admin_id'] = $row->id;   
          
            // update last activity time stamp

            $msg['msg'] = "Login success";
            $msg['error'] = 0;
        }else{
           $msg['msg'] = "Incorrect Email Or Password.";
           $msg['error'] = 1; 
        }
    }
}
echo json_encode($msg);
?>