<?php
$connect = mysqli_connect("localhost", "root", "", "db_product");
$output = '';


   if(isset($_GET["sq"])){
       $sq=$_GET["sq"];
   
  $result=mysqli_query( $connect,"select * from tbl_category where category_name LIKE '%$sq%'");
   

if(mysqli_num_rows($result) > 0)
{

 while($row = mysqli_fetch_assoc($result))
 {
  $output .= '
   <tr>
   <td align="center"><input type="checkbox" name="checked_id[]" class="checkbox" /></td>
   <td>'.$row["category_id"].'</td>
    <td>'.$row["category_name"].'</td>
    <td>'.$row["category_description"].'</td>
    <td>'.$row["category_status"].'</td>
    <td>'.$row["parent"].'</td>
 <td><a href="">Edit </a>|<a href=""> Delete</a></td>
   </tr>
  ';
 }
 echo $output;
}
   }

else
{
 echo 'Data Not Found';
}
?>