<?php
$host="localhost";
$user="root";
$password="";
$database="db_product";

$connection= mysqli_connect($host,$user,$password,$database);
session_start();



if($_POST)
{
		$email=$_POST['email'];
		$password=$_POST['password'];


	$query= mysqli_query($connection, "select *from tbl_admin where email='{$email}' and password='{$password}'")or die(mysqli_error($connection));

	
	$data =mysqli_fetch_row($query);
	if($data > 0)
	{ 
		$_SESSION["email"]=$email;
	header("location: Dashboard.php");
		
	}
	
	
}
?>


<html>
<head>
  <title>jQuery Validation</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
	function validateform(){
	
		
		var email=$('#email').val();
		if(email==""){
			$('#ErrorMsg').text('Please enter your Email!');
			$('#email').focus();
			return false;
		}
		var pattern = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if(!pattern.test(email)){
			$('#ErrorMsg').text('Please enter Valid Email!');
			$('#email').focus();
			return false;
		}
		var password=$('#password').val();
		if(password==""){
			$('#ErrorMsg').text('Please enter Password!');
			$('#password').focus();
			return false;
		}
		if(password.length <6){
			$('#ErrorMsg').text('Please enter six Character Password!');
			$('#password').focus();
			return false;
		}
		
	}
 
</script>

<style>

	</style>



	
	</head>
<body>

<div class="container">
  <div class="row">
    <div class="col-sm-6">
    <h2 align="center" >LoginForm</h2>
    <p id="ErrorMsg" style="color:red"></p>
		<form class="form-horizontal" action="Dashboard.php" onsubmit="return validateform();">
	
		
		<div class="form-group">
			<label class="control-label col-sm-2" for="email">Email:</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="email" placeholder="Enter email" name="email">
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2" for="pwd">Password:</label>
			<div class="col-sm-10">          
				<input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
			</div>
		</div>
	
		<div class="form-group">        
			<div class="col-sm-offset-2 col-sm-10">
				<button type="submit" class="btn btn-default">Submit</button>
			</div>
		</div>
		</form>
    </div>
  </div>
</div>
 
</body>
</html>