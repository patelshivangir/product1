<html>
 <head>
	 <style>
		 body{
	
	background:#f2f2f2;
      border: 1px solid #000033;
    padding:10px;
	}
.nav{
	width:100%;
	background:#000033;
	height:80px;
		}
			
	form {
  border: 3px solid #f1f1f1;
		
		margin:0;
		
}


				
ul{
	list-style:none;
	padding:0;
	margin:0;
	position:relative;
			}
ul li{
	float:left;
	margin-top:20px;
				}
ul li a{
	width:150px;
	color:white;
	display:block;
	text-decoration:none;
	font-size:20px;
	text-align:center;
	padding:10px;
	border-radius:10px;
	font-family:Century Gothic;
	font-weight:bold;
				}

ul li ul{
	background:#000033;}
ul li ul li{
	float:none;
		}
ul li ul{
	display:none;
	
	}
ul li:hover ul{
	display:block;
	overflow:hide;
				}
/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
	 </style>
	 <style>
	div.pagination {
    font-family: "Lucida Sans", Geneva, Verdana, sans-serif;
    padding:20px;
    margin:7px;
}
div.pagination a {
    margin: 2px;
    padding: 0.5em 0.64em 0.43em 0.64em;
    background-color: #4CAF50;
    text-decoration: none;
    color: #fff;
}
div.pagination a:hover, div.pagination a:active {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #4CAF50;
    color: #fff;
}
div.pagination span.current {
    padding: 0.5em 0.64em 0.43em 0.64em;
    margin: 2px;
    background-color: #f6efcc;
    color: #6d643c;
}
div.pagination span.disabled {
    display:none;
}
	</style>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>category</title>
	 <script src="jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
 </head>
 <body>
	 	<div class="nav">
			<ul>
				<li><a href="Dashboard.php">Dashboard</a></li>
				
				<li><a href="add-category.php">Add category</a></li> 
				<li><a href="view-category.php">View category</a></li>
			
					<li><a href="add-product-details.php">Add Product</a></li>
				<li><a href="view-product.php">View Product</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
	</div>	
  <div class="container">
   <br />
   <h2 align="center">View Category</h2><br />
   <div class="form-group">
    <div class="input-group">
     <span class="input-group-addon">Search</span>
     <input type="text" name="search_text" id="search_text" placeholder="Search by Customer Details" class="form-control" />
    </div>
   </div>
   <br />
   <div id="result"></div>
  </div>
 </body>
</html>

<?php
session_start();


// Load pagination class
require_once '/opt/lampp/htdocs/Product/Pagination.class.php';



// Load and initialize database class
require_once '/opt/lampp/htdocs/Product/DB.class.php';
$db = new db();
if(isset($_GET["record"])){
       $record=$_GET["record"];
   
 }
  else{
         $record=5;
     }

$perPageLimit = $record;
$offset = !empty($_GET['page'])?(($_GET['page']-1)*$perPageLimit):0;

 //Get search keyword
$searchKeyword = !empty($_GET['sq'])?$_GET['sq']:'';
$searchStr = !empty($searchKeyword)?'?sq='.$searchKeyword:'';

 //Search DB query
$searchArr = '';
if(!empty($searchKeyword)){
   $searchArr = array(
       'category_name' => $searchKeyword,
        'category_description' => $searchKeyword,
        'category_status' => $searchKeyword
    );
}

 //Get count of the users
$con = array(
    'like_or' => $searchArr,
    'return_type' => 'count'
);
$rowCount = $db->getRows('tbl_category', $con);

 //Initialize pagination class
$pagConfig = array(
    'baseURL' => 'ajax.php'.$searchStr,
    'totalRows' => $rowCount,
    'perPage' => $perPageLimit
);
$pagination = new Pagination($pagConfig);

// Get users from database
$con = array(
    'like_or' => $searchArr,
    'start' => $offset,
    'limit' => $perPageLimit,
    'order_by' => 'category_id ASC',
);
$tbl_category = $db->getRows('tbl_category', $con);

?>

<!-- Display status message -->
<?php if(!empty($statusMsg) && ($statusMsgType == 'success')){ ?>
<div class="alert alert-success"><?php echo $statusMsg; ?></div>
<?php }elseif(!empty($statusMsg) && ($statusMsgType == 'error')){ ?>
<div class="alert alert-danger"><?php echo $statusMsg; ?></div>
<?php } ?>

<script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"GET",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>
 <form method="get">
	 <select name="record"  onchange="valueselect(this.value);">
                <option value="5" selected> <a href="view-category.php?id=<?php echo $record; ?>">5</a></option>
                  <option value="10" ><a href="view-category.php?id=<?php echo $record; ?>">10</a></option>
                      <option value="20" ><a href="view-category.php?id=<?php echo $record; ?>">20</a></option>
                 </select>
                    <input type="submit" >
</form>
 <?php  echo $pagination->createLinks(); ?>
